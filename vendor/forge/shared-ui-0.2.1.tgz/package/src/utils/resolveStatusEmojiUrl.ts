import type { CustomEmoji } from '../types/custom-emoji';

/**
 * Resolves a status emoji string to a custom emoji image URL.
 * Returns undefined for unicode emojis (non-shortcode format).
 */
export function resolveStatusEmojiUrl(
  emoji: string | undefined,
  customEmojiMap: Map<string, CustomEmoji> | undefined,
): string | undefined {
  if (!emoji || !customEmojiMap) return undefined;
  const match = emoji.match(/^:(.+):$/);
  if (!match) return undefined;
  return customEmojiMap.get(match[1])?.image_url;
}
