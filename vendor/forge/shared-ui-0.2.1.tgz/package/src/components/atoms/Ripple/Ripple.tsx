import './Ripple.css';
import { useCallback, useEffect, useRef, useState } from 'react';

interface RippleData {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
}

export interface UseRippleOptions {
  color?: string;
}

export interface UseRippleResult {
  ref: (node: HTMLElement | null) => void;
  trigger: (point: { x: number; y: number }) => void;
  element: React.ReactNode;
}

let nextId = 0;

function isCoarsePointer(): boolean {
  return typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches;
}

function resolveColor(el: HTMLElement): string {
  let node: HTMLElement | null = el;
  while (node) {
    const bg = window.getComputedStyle(node).backgroundColor;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
      const m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (m) {
        const lum = 0.299 * Number(m[1]) + 0.587 * Number(m[2]) + 0.114 * Number(m[3]);
        return lum > 128 ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.16)';
      }
      return 'rgba(0,0,0,0.1)';
    }
    node = node.parentElement;
  }
  return 'rgba(0,0,0,0.1)';
}

export function useRipple(options?: UseRippleOptions): UseRippleResult {
  const [ripples, setRipples] = useState<RippleData[]>([]);
  const containerRef = useRef<HTMLElement | null>(null);
  const mountedRef = useRef(true);
  const mountTimeRef = useRef(performance.now());
  const cachedColorRef = useRef<string | null>(null);
  const prevColorPropRef = useRef<string | undefined>(undefined);
  const colorProp = options?.color;

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const ref = useCallback((node: HTMLElement | null) => {
    containerRef.current = node;
  }, []);

  const trigger = useCallback(
    (point: { x: number; y: number }) => {
      // Ignore phantom touchstart immediately after mount (iOS back-swipe gesture
      // dispatches a stray touchstart on the freshly-mounted route).
      if (performance.now() - mountTimeRef.current < 300) return;
      if (!isCoarsePointer()) return;
      const el = containerRef.current;
      if (!el) return;
      if (prevColorPropRef.current !== colorProp) {
        cachedColorRef.current = null;
        prevColorPropRef.current = colorProp;
      }
      const rect = el.getBoundingClientRect();
      const x = point.x - rect.left;
      const y = point.y - rect.top;
      const dx = Math.max(x, rect.width - x);
      const dy = Math.max(y, rect.height - y);
      const size = Math.sqrt(dx * dx + dy * dy) * 2;
      let color: string;
      if (colorProp) {
        color = colorProp;
      } else {
        if (!cachedColorRef.current) {
          cachedColorRef.current = resolveColor(el);
        }
        color = cachedColorRef.current;
      }
      setRipples((prev) => [...prev, { id: nextId++, x, y, size, color }]);
    },
    [colorProp],
  );

  const removeRipple = useCallback((id: number) => {
    if (!mountedRef.current) return;
    setRipples((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const element =
    ripples.length > 0
      ? ripples.map((r) => (
          <span
            key={r.id}
            onAnimationEnd={() => removeRipple(r.id)}
            style={{
              position: 'absolute',
              left: r.x - r.size / 2,
              top: r.y - r.size / 2,
              width: r.size,
              height: r.size,
              borderRadius: '50%',
              backgroundColor: r.color,
              pointerEvents: 'none' as const,
              transformOrigin: 'center',
              willChange: 'transform, opacity',
              animation: 'ripple-expand var(--gf-dur-glacial) var(--gf-ease-out) forwards',
            }}
          />
        ))
      : null;

  return { ref, trigger, element };
}
