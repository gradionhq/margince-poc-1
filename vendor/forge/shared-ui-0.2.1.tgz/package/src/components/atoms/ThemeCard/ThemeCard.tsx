import type { ThemeCardProps } from '../../../types/props';

function LightPreview() {
  return (
    <div className="flex h-[120px] w-full flex-col gap-1.5 overflow-hidden rounded-xl border border-gf-subtle bg-neutral-50 p-gf-md">
      <div className="h-2.5 w-full rounded bg-neutral-200" />
      <div className="h-1.5 w-full rounded-sm bg-neutral-300" />
      <div className="h-1.5 w-20 rounded-sm bg-neutral-300" />
      <div className="w-full flex-1 rounded-md border border-neutral-200 bg-white" />
    </div>
  );
}

function DarkPreview() {
  return (
    <div className="flex h-[120px] w-full flex-col gap-1.5 overflow-hidden rounded-xl border border-gf-subtle bg-neutral-900 p-gf-md">
      <div className="h-2.5 w-full rounded bg-neutral-700" />
      <div className="h-1.5 w-full rounded-sm bg-neutral-600" />
      <div className="h-1.5 w-20 rounded-sm bg-neutral-600" />
      <div className="w-full flex-1 rounded-md border border-neutral-700 bg-neutral-800" />
    </div>
  );
}

function SystemPreview() {
  return (
    <div className="flex h-[120px] w-full overflow-hidden rounded-xl border border-gf-subtle">
      <div className="flex flex-1 flex-col gap-1.5 bg-neutral-50 p-gf-md">
        <div className="h-2.5 w-full rounded bg-neutral-200" />
        <div className="h-1.5 w-full rounded-sm bg-neutral-300" />
        <div className="w-full flex-1 rounded-md bg-white" />
      </div>
      <div className="flex flex-1 flex-col gap-1.5 bg-neutral-900 p-gf-md">
        <div className="h-2.5 w-full rounded bg-neutral-700" />
        <div className="h-1.5 w-full rounded-sm bg-neutral-600" />
        <div className="w-full flex-1 rounded-md bg-neutral-800" />
      </div>
    </div>
  );
}

const PREVIEWS = { light: LightPreview, dark: DarkPreview, system: SystemPreview };

export function ThemeCard({ variant, selected, onClick, label }: ThemeCardProps) {
  const Preview = PREVIEWS[variant];
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-1 cursor-pointer flex-col items-center gap-2.5"
    >
      <div className={`w-full ${selected ? 'rounded-xl ring-2 ring-gf-accent' : ''}`}>
        <Preview />
      </div>
      <div className="flex items-center gap-gf-sm">
        <div
          className={`flex h-[18px] w-[18px] items-center justify-center rounded-full border-2 ${selected ? 'border-gf-accent' : 'border-gf-muted'}`}
        >
          {selected && <div className="h-2.5 w-2.5 rounded-full bg-gf-accent" />}
        </div>
        <span className={`text-sm font-medium ${selected ? 'text-gf-accent' : 'text-gf-primary'}`}>
          {label}
        </span>
      </div>
    </button>
  );
}
