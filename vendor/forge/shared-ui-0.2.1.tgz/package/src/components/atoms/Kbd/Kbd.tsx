import type { KbdProps } from '../../../types/props';

export function Kbd({ keys, className = '' }: KbdProps) {
  return (
    <span className={`inline-flex items-center gap-gf-xs text-gf-small font-mono ${className}`}>
      {keys.map((key, i) => (
        <span key={key} className="inline-flex items-center gap-gf-xs">
          {i > 0 && <span>+</span>}
          <kbd className="bg-gf-card border border-gf-subtle rounded-sm px-1.5 py-0.5">{key}</kbd>
        </span>
      ))}
    </span>
  );
}
