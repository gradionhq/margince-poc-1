import type { SkeletonProps } from '../../../types/props';

export function Skeleton({
  variant = 'bar',
  width,
  height,
  aspectRatio,
  className = '',
}: SkeletonProps) {
  const isCircle = variant === 'circle';
  const isBlock = variant === 'block';
  const resolvedWidth = width ?? (isCircle ? '40px' : '100%');
  const resolvedHeight = height ?? (isCircle ? '40px' : isBlock ? undefined : '16px');
  // `block` variant matches the rounded-lg used by file-thumbnail / file-detail
  // placeholders (preserving prior visual). Bar and default keep rounded-md.
  const shape = isCircle ? 'rounded-full' : isBlock ? 'rounded-lg' : 'rounded-md';

  return (
    <div
      data-testid="skeleton"
      className={`animate-pulse bg-gf-card ${shape} ${className}`}
      style={{ width: resolvedWidth, height: resolvedHeight, aspectRatio }}
    />
  );
}
