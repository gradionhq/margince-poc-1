import type { ButtonProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

const sizeClasses = {
  sm: 'h-8 px-gf-md text-gf-small',
  md: 'h-10 px-gf-lg text-gf-label',
  lg: 'h-12 px-gf-xl text-gf-label',
} as const;

const variantClasses = {
  primary: 'bg-gf-accent text-gf-on-accent hover:opacity-90',
  secondary: 'bg-gf-elevated text-gf-primary border border-gf-subtle hover:bg-gf-card',
  'accent-outline':
    'bg-gf-accent/10 text-gf-accent border border-gf-accent/30 hover:bg-gf-accent/20',
  ghost: 'bg-transparent text-gf-secondary hover:bg-gf-card hover:text-gf-primary',
  danger:
    'bg-gf-card text-gf-status-danger border border-gf-status-danger/40 hover:bg-gf-status-danger/10 hover:border-gf-status-danger/60',
} as const;

const focusRingClasses = {
  primary: 'focus:ring-gf-accent',
  secondary: 'focus:ring-gf-accent',
  'accent-outline': 'focus:ring-gf-accent',
  ghost: 'focus:ring-gf-accent',
  danger: 'focus:ring-gf-status-danger/50',
} as const;

function Spinner() {
  return (
    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none" aria-label="Loading">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
      />
    </svg>
  );
}

export function Button({
  variant = 'primary',
  size = 'md',
  icon,
  children,
  onClick,
  disabled = false,
  loading = false,
  className = '',
  type = 'button',
  ...rest
}: ButtonProps) {
  const iconSize = size === 'sm' ? 14 : 16;
  const isDisabled = disabled || loading;

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={isDisabled}
      aria-busy={loading || undefined}
      data-testid={rest['data-testid']}
      className={`inline-flex items-center justify-center gap-gf-sm rounded-md font-gf-label transition-colors focus:outline-none focus:ring-2 ${focusRingClasses[variant]} disabled:opacity-50 disabled:cursor-not-allowed ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {loading ? <Spinner /> : icon && <Icon name={icon} size={iconSize} />}
      {children}
    </button>
  );
}
