import type { TextInputProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

export function TextInput({
  placeholder,
  value,
  onChange,
  onKeyDown,
  leadingIcon,
  trailingIcon,
  className = '',
  disabled = false,
  type = 'text',
}: TextInputProps) {
  return (
    <div className={`relative flex items-center ${className}`}>
      {leadingIcon && (
        <span className="absolute left-3 text-gf-tertiary pointer-events-none">
          <Icon name={leadingIcon} size={16} />
        </span>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        onKeyDown={onKeyDown}
        disabled={disabled}
        className={`h-10 w-full rounded-md bg-gf-elevated border border-gf-subtle text-gf-body text-gf-primary placeholder:text-gf-muted transition-colors focus:border-gf-accent focus:ring-1 focus:ring-gf-accent focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed ${leadingIcon ? 'pl-10' : 'pl-gf-md'} ${trailingIcon ? 'pr-10' : 'pr-gf-md'}`}
      />
      {trailingIcon && (
        <span className="absolute right-3 text-gf-tertiary pointer-events-none">
          <Icon name={trailingIcon} size={16} />
        </span>
      )}
    </div>
  );
}
