import { useCallback, useEffect, useRef, useState } from 'react';
import type { FilterDropdownProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

export function FilterDropdown({
  label,
  value,
  options,
  onChange,
  className = '',
}: FilterDropdownProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find((o) => o.value === value);
  const displayLabel = selectedOption?.label ?? value;

  const handleSelect = useCallback(
    (optionValue: string) => {
      onChange(optionValue);
      setOpen(false);
    },
    [onChange],
  );

  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  return (
    <div ref={containerRef} className={`relative inline-block ${className}`}>
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="inline-flex items-center gap-1.5 rounded-sm border border-gf-subtle bg-gf-elevated px-gf-md py-1.5 text-gf-small text-gf-primary hover:bg-gf-card transition-colors"
      >
        <span>
          {label}: {displayLabel}
        </span>
        <Icon name="ChevronDown" size={14} />
      </button>

      {open && (
        <ul
          role="listbox"
          className="absolute left-0 top-full z-gf-dropdown mt-gf-xs min-w-full rounded-sm border border-gf-subtle bg-gf-elevated shadow-lg"
        >
          {options.map((option) => (
            <li
              key={option.value}
              role="option"
              aria-selected={option.value === value}
              tabIndex={0}
              className="cursor-pointer px-gf-md py-1.5 text-gf-small text-gf-primary hover:bg-gf-card transition-colors first:rounded-t-sm last:rounded-b-sm"
              onClick={() => handleSelect(option.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleSelect(option.value);
                }
              }}
            >
              {option.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
