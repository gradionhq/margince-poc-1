import type { StatusDotProps, StatusDotState } from '../../../types/props';

const stateBgClass: Record<StatusDotState, string> = {
  running: 'bg-gf-agent-aria',
  success: 'bg-gf-status-success',
  error: 'bg-gf-status-danger',
};

const defaultLabel: Record<StatusDotState, string> = {
  running: 'Running',
  success: 'Completed',
  error: 'Failed',
};

const sizeClasses = {
  sm: 'h-2 w-2',
  md: 'h-2.5 w-2.5',
  lg: 'h-3 w-3',
} as const;

export function StatusDot({ state, className = '', size = 'sm', ariaLabel }: StatusDotProps) {
  return (
    <output
      data-testid="status-dot"
      data-state={state}
      aria-label={ariaLabel ?? defaultLabel[state]}
      className={`inline-block rounded-full ${sizeClasses[size]} ${stateBgClass[state]} ${className}`}
    />
  );
}
