import {
  createContext,
  type ReactNode,
  type RefObject,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from 'react';
import { createPortal } from 'react-dom';
import { useScrollLock } from '../../../hooks/useScrollLock';

export type PopoverPlacement =
  | 'bottom-left'
  | 'bottom-right'
  | 'bottom-center'
  | 'top-left'
  | 'top-center'
  | 'top-right';

export const PopoverPlacementContext = createContext<PopoverPlacement>('top-center');

export interface PopoverPortalProps {
  anchorRef: RefObject<HTMLElement | null>;
  placement: PopoverPlacement;
  children: ReactNode;
  className?: string;
  /** When provided, called on click outside the popover content */
  onClickOutside?: () => void;
  /** When true, renders an invisible full-screen backdrop that blocks interaction with underlying UI */
  backdrop?: boolean;
}

const OFFSET = 4;
const VIEWPORT_PADDING = 8;

interface Position {
  top: number;
  left: number;
  transform?: string;
}

export function computePosition(rect: DOMRect, placement: PopoverPlacement): Position {
  switch (placement) {
    case 'bottom-left':
      return { top: rect.bottom + OFFSET, left: rect.left };
    case 'bottom-right':
      return { top: rect.bottom + OFFSET, left: rect.right, transform: 'translateX(-100%)' };
    case 'bottom-center':
      return {
        top: rect.bottom + OFFSET,
        left: rect.left + rect.width / 2,
        transform: 'translateX(-50%)',
      };
    case 'top-left':
      return { top: rect.top - OFFSET, left: rect.left, transform: 'translateY(-100%)' };
    case 'top-center':
      return {
        top: rect.top - OFFSET,
        left: rect.left + rect.width / 2,
        transform: 'translateX(-50%) translateY(-100%)',
      };
    case 'top-right':
      return {
        top: rect.top - OFFSET,
        left: rect.right,
        transform: 'translateX(-100%) translateY(-100%)',
      };
  }
}

/**
 * Resolves CSS transform offsets into pixel positions.
 * Returns a transform-free position with the same visual result.
 */
export function resolveToPixels(
  pos: Position,
  contentWidth: number,
  contentHeight: number,
): { top: number; left: number } {
  let { top, left } = pos;
  const t = pos.transform ?? '';
  if (t.includes('translateY(-100%)')) top -= contentHeight;
  if (t.includes('translateX(-100%)')) left -= contentWidth;
  else if (t.includes('translateX(-50%)')) left -= contentWidth / 2;
  return { top, left };
}

/**
 * Clamps a resolved pixel position to stay within the viewport with padding.
 */
export function clampToViewport(
  top: number,
  left: number,
  contentWidth: number,
  contentHeight: number,
  viewportWidth: number,
  viewportHeight: number,
): { top: number; left: number } {
  let t = top;
  let l = left;
  if (t + contentHeight > viewportHeight - VIEWPORT_PADDING) {
    t = viewportHeight - contentHeight - VIEWPORT_PADDING;
  }
  if (t < VIEWPORT_PADDING) {
    t = VIEWPORT_PADDING;
  }
  if (l + contentWidth > viewportWidth - VIEWPORT_PADDING) {
    l = viewportWidth - contentWidth - VIEWPORT_PADDING;
  }
  if (l < VIEWPORT_PADDING) {
    l = VIEWPORT_PADDING;
  }
  return { top: t, left: l };
}

export function PopoverPortal({
  anchorRef,
  placement,
  children,
  className = '',
  onClickOutside,
  backdrop,
}: PopoverPortalProps) {
  useScrollLock(true);
  const [pos, setPos] = useState<Position | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // Compute position and clamp to viewport in a single pass
  useLayoutEffect(() => {
    if (!anchorRef.current) {
      setPos(null);
      return;
    }
    const rect = anchorRef.current.getBoundingClientRect();
    const activePlacement = placement;
    const computed = computePosition(rect, activePlacement);

    // Schedule a post-render clamp after the portal content is measured
    setPos(computed);

    // Use rAF to measure after the portal renders, then resolve transforms and clamp.
    // No flip — Slack-like behavior: keep menu close to anchor, shift to stay in viewport.
    const raf = requestAnimationFrame(() => {
      if (!contentRef.current) return;
      const elRect = contentRef.current.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // Resolve CSS transforms to actual pixel position, then clamp to viewport
      const resolved = resolveToPixels(computed, elRect.width, elRect.height);
      const clamped = clampToViewport(
        resolved.top,
        resolved.left,
        elRect.width,
        elRect.height,
        vw,
        vh,
      );

      const finalPos: Position = { top: clamped.top, left: clamped.left };

      if (finalPos.top !== computed.top || finalPos.left !== computed.left || computed.transform) {
        setPos(finalPos);
      }
    });

    return () => cancelAnimationFrame(raf);
  }, [anchorRef, placement]);

  // Click outside handler — also ignores clicks inside nested portals
  // (e.g. ReminderMenu rendered via a child PopoverPortal).
  useEffect(() => {
    if (!onClickOutside) return;
    function handleClick(e: MouseEvent) {
      const target = e.target as Node;
      if (
        contentRef.current &&
        !contentRef.current.contains(target) &&
        anchorRef.current &&
        !anchorRef.current.contains(target)
      ) {
        // Don't close if the click landed inside a nested portal that is a
        // logical child of this one (e.g. submenu portalled to body).
        const targetPortal = (target as Element).closest?.('[data-portal-root]');
        if (targetPortal && targetPortal !== contentRef.current) {
          // Click is inside another portal — check if it rendered AFTER ours
          // in DOM order (i.e. it's a child submenu, not an unrelated portal).
          const allPortals = document.querySelectorAll('[data-portal-root]');
          const portalsArray = Array.from(allPortals);
          const ourIdx = portalsArray.indexOf(contentRef.current);
          const targetIdx = portalsArray.indexOf(targetPortal);
          if (ourIdx >= 0 && targetIdx > ourIdx) {
            // Target portal appears after ours — it's a nested child, skip close.
            return;
          }
        }
        onClickOutside?.();
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [onClickOutside, anchorRef]);

  if (!pos) return null;

  return createPortal(
    <>
      {backdrop && (
        <button
          type="button"
          aria-label="Close menu"
          tabIndex={-1}
          className="fixed inset-0 z-gf-toast cursor-default"
          onClick={onClickOutside}
          onContextMenu={(e) => {
            e.preventDefault();
            onClickOutside?.();
          }}
        />
      )}
      <div
        ref={contentRef}
        data-portal-root
        className={`fixed z-gf-tooltip ${className}`}
        style={{ top: pos.top, left: pos.left, transform: pos.transform }}
      >
        <PopoverPlacementContext.Provider value={placement}>
          {children}
        </PopoverPlacementContext.Provider>
      </div>
    </>,
    document.body,
  );
}
