import { useState } from 'react';
import type { ConfirmDialogProps } from '../../../types/props';
import { Button } from '../Button/Button';
import { Modal } from '../Modal/Modal';

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = 'Confirm',
  confirmVariant = 'primary',
  requireConfirmText,
  isLoading = false,
}: ConfirmDialogProps) {
  const [confirmInput, setConfirmInput] = useState('');

  const isConfirmDisabled = requireConfirmText !== undefined && confirmInput !== requireConfirmText;

  const confirmButtonVariant = confirmVariant === 'destructive' ? 'secondary' : 'primary';

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      width="sm"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant={confirmButtonVariant}
            onClick={onConfirm}
            disabled={isConfirmDisabled}
            loading={isLoading}
            className={
              confirmVariant === 'destructive'
                ? 'bg-gf-status-danger hover:bg-gf-status-danger/90 text-gf-on-accent'
                : ''
            }
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="px-gf-xl py-gf-lg">
        <p className="text-gf-body text-gf-secondary">{description}</p>
        {requireConfirmText !== undefined && (
          <div className="mt-gf-lg">
            <input
              type="text"
              value={confirmInput}
              onChange={(e) => setConfirmInput(e.target.value)}
              placeholder={requireConfirmText}
              className="h-10 w-full rounded-md bg-gf-elevated border border-gf-subtle text-gf-body text-gf-primary placeholder:text-gf-muted transition-colors focus:border-gf-accent focus:ring-1 focus:ring-gf-accent focus:outline-none px-gf-md"
            />
          </div>
        )}
      </div>
    </Modal>
  );
}
