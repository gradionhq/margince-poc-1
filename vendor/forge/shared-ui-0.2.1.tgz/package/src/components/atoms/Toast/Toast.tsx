import type { ToastProps, ToastVariant } from '../../../types/props';

const variantStyles: Record<
  ToastVariant,
  { container: string; icon: string; title: string; message: string; close: string }
> = {
  error: {
    container: 'bg-gf-status-danger-subtle border-red-200 dark:border-red-900',
    icon: 'text-red-600 dark:text-red-400',
    title: 'text-red-900 dark:text-red-200',
    message: 'text-gf-status-danger-fg',
    close: 'text-gf-status-danger-fg hover:text-red-900 dark:hover:text-red-100',
  },
  success: {
    container: 'bg-gf-status-success-subtle border-green-200 dark:border-green-900',
    icon: 'text-green-600 dark:text-green-400',
    title: 'text-green-900 dark:text-green-200',
    message: 'text-gf-status-success-fg',
    close: 'text-gf-status-success-fg hover:text-green-900 dark:hover:text-green-100',
  },
  warning: {
    container: 'bg-gf-status-warning-subtle border-amber-200 dark:border-amber-900',
    icon: 'text-amber-600 dark:text-amber-400',
    title: 'text-amber-900 dark:text-amber-200',
    message: 'text-gf-status-warning-fg',
    close: 'text-gf-status-warning-fg hover:text-amber-900 dark:hover:text-amber-100',
  },
  info: {
    container: 'bg-gf-status-info-subtle border-blue-200 dark:border-blue-900',
    icon: 'text-blue-600 dark:text-blue-400',
    title: 'text-blue-900 dark:text-blue-200',
    message: 'text-gf-status-info-fg',
    close: 'text-gf-status-info-fg hover:text-blue-900 dark:hover:text-blue-100',
  },
};

const iconPaths: Record<ToastVariant, string> = {
  error:
    'M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z',
  success:
    'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
  warning: 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
  info: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z',
};

export function Toast({ id, variant, title, message, onClose }: ToastProps) {
  const styles = variantStyles[variant];

  return (
    <div
      role="alert"
      data-testid={`toast-${id}`}
      className={`flex w-full items-center gap-gf-md rounded-xl border px-gf-lg py-3.5 shadow-sm sm:w-[400px] ${styles.container}`}
    >
      <svg
        viewBox="0 0 24 24"
        className={`h-5 w-5 shrink-0 ${styles.icon}`}
        fill="currentColor"
        aria-hidden="true"
      >
        <path d={iconPaths[variant]} />
      </svg>
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <p className={`text-sm font-semibold leading-snug ${styles.title}`}>{title}</p>
        {message && <p className={`text-gf-caption leading-snug ${styles.message}`}>{message}</p>}
      </div>
      {onClose && (
        <button
          type="button"
          onClick={() => onClose(id)}
          className={`shrink-0 rounded-md p-0.5 transition-colors ${styles.close}`}
          aria-label="Dismiss"
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
          </svg>
        </button>
      )}
    </div>
  );
}
