import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

interface LinkHoverPreviewProps {
  /** The element whose descendant <a> tags should show the preview on hover. */
  rootRef: React.RefObject<HTMLElement | null>;
}

interface HoverState {
  url: string;
  top: number;
  left: number;
}

/** Position the bubble just above an anchor's top-left corner. */
function computePosition(anchor: HTMLAnchorElement): { top: number; left: number } {
  const rect = anchor.getBoundingClientRect();
  return { top: rect.top - 8, left: rect.left };
}

/**
 * Delegated hover preview: shows a small portal bubble with the URL above any
 * `<a>` tag rendered inside `rootRef`. Use from the editor or from message bodies
 * so users can verify a link's destination before clicking or sending.
 */
export function LinkHoverPreview({ rootRef }: LinkHoverPreviewProps) {
  const [hover, setHover] = useState<HoverState | null>(null);
  const activeAnchorRef = useRef<HTMLAnchorElement | null>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    const show = (anchor: HTMLAnchorElement) => {
      const href = anchor.getAttribute('href');
      if (!href) return;
      activeAnchorRef.current = anchor;
      setHover({ url: href, ...computePosition(anchor) });
    };

    const clear = () => {
      activeAnchorRef.current = null;
      setHover(null);
    };

    const handleOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const anchor = target?.closest('a') as HTMLAnchorElement | null;
      if (anchor && root.contains(anchor) && anchor !== activeAnchorRef.current) {
        show(anchor);
      }
    };

    const handleOut = (e: MouseEvent) => {
      const current = activeAnchorRef.current;
      if (!current) return;
      const related = e.relatedTarget as Node | null;
      // Ignore moves between descendants of the same anchor (avoids flicker).
      if (related && current.contains(related)) return;
      clear();
    };

    const reposition = () => {
      const current = activeAnchorRef.current;
      if (!current) return;
      // Anchor detached (DOM update) → dismiss.
      if (!current.isConnected) {
        clear();
        return;
      }
      setHover({ url: current.getAttribute('href') ?? '', ...computePosition(current) });
    };

    root.addEventListener('mouseover', handleOver);
    root.addEventListener('mouseout', handleOut);
    window.addEventListener('scroll', reposition, true);
    window.addEventListener('resize', reposition);

    return () => {
      root.removeEventListener('mouseover', handleOver);
      root.removeEventListener('mouseout', handleOut);
      window.removeEventListener('scroll', reposition, true);
      window.removeEventListener('resize', reposition);
    };
  }, [rootRef]);

  if (!hover) return null;

  return createPortal(
    <div
      role="tooltip"
      className="fixed z-gf-tooltip max-w-sm truncate rounded-md bg-gf-elevated border border-gf-subtle px-gf-sm py-gf-xs text-gf-small text-gf-primary shadow-md pointer-events-none"
      style={{ top: hover.top, left: hover.left, transform: 'translateY(-100%)' }}
    >
      {hover.url}
    </div>,
    document.body,
  );
}
