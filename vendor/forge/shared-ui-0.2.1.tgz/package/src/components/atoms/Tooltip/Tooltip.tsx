import { useCallback, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import type { TooltipProps } from '../../../types/props';

export function Tooltip({ content, children, side = 'top', className = '' }: TooltipProps) {
  const triggerRef = useRef<HTMLSpanElement>(null);
  const [visible, setVisible] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const show = useCallback(() => {
    const el = triggerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    let top: number;
    let left: number;
    switch (side) {
      case 'bottom':
        top = rect.bottom + 8;
        left = rect.left + rect.width / 2;
        break;
      case 'left':
        top = rect.top + rect.height / 2;
        left = rect.left - 8;
        break;
      case 'right':
        top = rect.top + rect.height / 2;
        left = rect.right + 8;
        break;
      default: // top
        top = rect.top - 8;
        left = rect.left + rect.width / 2;
        break;
    }
    setPos({ top, left });
    setVisible(true);
  }, [side]);

  const hide = useCallback(() => setVisible(false), []);

  const originClass =
    side === 'top'
      ? '-translate-x-1/2 -translate-y-full'
      : side === 'bottom'
        ? '-translate-x-1/2'
        : side === 'left'
          ? '-translate-x-full -translate-y-1/2'
          : '-translate-y-1/2';

  const arrowClass = (() => {
    const base = 'absolute w-0 h-0';
    switch (side) {
      case 'top':
        return `${base} bottom-[-5px] left-1/2 ml-[-6px] border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-gf-tooltip`;
      case 'bottom':
        return `${base} top-[-5px] left-1/2 ml-[-6px] border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[6px] border-b-gf-tooltip`;
      case 'left':
        return `${base} right-[-5px] top-1/2 mt-[-6px] border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-l-[6px] border-l-gf-tooltip`;
      case 'right':
        return `${base} left-[-5px] top-1/2 mt-[-6px] border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-r-[6px] border-r-gf-tooltip`;
    }
  })();

  return (
    // biome-ignore lint/a11y/noStaticElementInteractions: tooltip trigger needs mouse/focus tracking
    <span
      ref={triggerRef}
      className={`inline-flex ${className}`}
      onMouseEnter={show}
      onMouseLeave={hide}
      onFocus={show}
      onBlur={hide}
    >
      {children}
      {visible &&
        pos &&
        createPortal(
          <span
            role="tooltip"
            className={`fixed pointer-events-none bg-gf-tooltip text-gf-tooltip-text rounded-md text-gf-small px-gf-md py-1.5 whitespace-nowrap z-gf-tooltip ${originClass}`}
            style={{ top: pos.top, left: pos.left }}
          >
            {content}
            <span className={arrowClass} />
          </span>,
          document.body,
        )}
    </span>
  );
}
