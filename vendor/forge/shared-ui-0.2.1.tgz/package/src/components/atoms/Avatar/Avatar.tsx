import { Bot } from 'lucide-react';
import { useContext } from 'react';
import { AvatarConfigContext } from '../../../context/AvatarConfigContext';
import { useAvatarBust } from '../../../hooks/useAvatarBust';
import type { AvatarProps } from '../../../types/props';

const botSizeConfig = {
  xs: { container: 'h-5 w-5', iconSize: 12 },
  sm: { container: 'h-8 w-8', iconSize: 18 },
  md: { container: 'h-10 w-10', iconSize: 22 },
} as const;

function BotAvatar({
  size = 'md',
  src,
  alt,
}: {
  size?: 'xs' | 'sm' | 'md';
  src?: string;
  alt?: string;
}) {
  const config = botSizeConfig[size];
  return (
    <div data-testid="bot-avatar" className={`relative shrink-0 ${config.container}`}>
      <div
        className={`${config.container} rounded-[10px] overflow-hidden flex items-center justify-center ${src ? '' : 'bg-gf-teal'}`}
      >
        {src ? (
          <img src={src} alt={alt ?? ''} className="h-full w-full object-cover" />
        ) : (
          <Bot size={config.iconSize} className="text-white" strokeWidth={1.75} />
        )}
      </div>
      {size !== 'xs' && (
        <span
          className="absolute right-0 bottom-0 translate-x-0.5 translate-y-0.5 rounded-full bg-gf-teal ring-1 ring-white px-[3px] py-[1px] text-white leading-none font-bold"
          style={{ fontSize: '7px' }}
        >
          BOT
        </span>
      )}
    </div>
  );
}

const sizeClasses = {
  xs: 'h-5 w-5 text-gf-mini',
  sm: 'h-8 w-8 text-gf-small',
  md: 'h-10 w-10 text-gf-body',
  lg: 'h-14 w-14 text-gf-heading',
  xl: 'h-20 w-20 text-2xl',
  profile: 'h-[240px] w-[240px] text-5xl',
} as const;

const botSizeMap: Record<string, 'xs' | 'sm' | 'md'> = {
  xs: 'xs',
  sm: 'sm',
  md: 'md',
  lg: 'md',
  xl: 'md',
  profile: 'md',
};

function getAvatarSrc(baseUrl: string, userId: string, bustParam?: string): string {
  const url = `${baseUrl}/api/users/${userId}/avatar`;
  return bustParam ? `${url}?v=${bustParam}` : url;
}

export function Avatar({
  name,
  avatarUrl,
  userId,
  hasAvatar,
  avatarBustParam,
  avatarBaseUrl,
  size = 'md',
  color,
  className = '',
  isBot,
}: AvatarProps) {
  const config = useContext(AvatarConfigContext);
  const baseUrl = avatarBaseUrl ?? config.baseUrl;
  const resolvedBust = useAvatarBust(userId, avatarBustParam);

  const src = hasAvatar && userId ? getAvatarSrc(baseUrl, userId, resolvedBust) : avatarUrl;
  if (isBot) {
    return <BotAvatar size={botSizeMap[size] ?? 'md'} src={src} alt={name} />;
  }
  const initial = name.charAt(0).toUpperCase();
  const sizeClass = sizeClasses[size];

  if (src) {
    return (
      <div
        data-testid="avatar"
        className={`${sizeClass} rounded-full overflow-hidden shrink-0 ${className}`}
      >
        <img src={src} alt={name} className="h-full w-full object-cover" />
      </div>
    );
  }

  return (
    <div
      data-testid="avatar"
      className={`${sizeClass} rounded-full flex items-center justify-center shrink-0 font-gf-heading font-semibold text-gf-on-accent ${color ? '' : 'bg-gf-accent'} ${className}`}
      style={color ? { backgroundColor: color } : undefined}
    >
      {initial}
    </div>
  );
}
