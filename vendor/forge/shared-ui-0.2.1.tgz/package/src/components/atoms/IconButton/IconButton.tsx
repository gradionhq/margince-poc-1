import type { IconButtonProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

const sizeClasses = {
  sm: 'h-8 w-8',
  md: 'h-10 w-10',
} as const;

const variantClasses = {
  default: 'hover:bg-gf-card',
  ghost: 'hover:bg-gf-card/50',
} as const;

export function IconButton({
  icon,
  onClick,
  label,
  variant = 'default',
  size = 'md',
  className = '',
  disabled = false,
}: IconButtonProps) {
  const iconSize = size === 'sm' ? 16 : 20;

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      disabled={disabled}
      className={`inline-flex items-center justify-center rounded-md text-gf-secondary transition-colors focus:outline-none focus:ring-2 focus:ring-gf-accent disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      <Icon name={icon} size={iconSize} />
    </button>
  );
}
