import type { DividerProps } from '../../../types/props';

// border-0 (not border-none) so we win over the UA stylesheet's
// `hr { border-width: 1px; border-style: inset; }` which beats Tailwind's
// `*` preflight on specificity. Without this the hr keeps a 1px dark
// border from the inherited text color and the divider renders thicker
// + darker than --gf-border-subtle.
const orientationClasses = {
  horizontal: 'h-px w-full border-0',
  vertical: 'w-px h-full border-0',
} as const;

export function Divider({ orientation = 'horizontal', className = '' }: DividerProps) {
  return (
    <hr
      aria-orientation={orientation}
      className={`bg-gf-subtle ${orientationClasses[orientation]} ${className}`}
    />
  );
}
