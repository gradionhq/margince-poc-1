import type { BadgeProps } from '../../../types/props';

export function Badge({ count, max = 99, variant = 'default' }: BadgeProps) {
  if (count === 0) {
    return null;
  }

  if (variant === 'dot') {
    return <span data-testid="badge" className="block h-2 w-2 rounded-full bg-gf-unread" />;
  }

  const display = count > max ? `${max}+` : String(count);

  return (
    <span
      data-testid="badge"
      className="inline-flex items-center justify-center rounded-full bg-gf-unread text-gf-on-accent text-gf-small font-semibold min-w-5 h-5 px-1.5"
    >
      {display}
    </span>
  );
}
