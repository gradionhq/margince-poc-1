import { AlertTriangle } from 'lucide-react';

export interface InlineErrorFallbackProps {
  onReset: () => void;
  message?: string;
}

export function InlineErrorFallback({
  onReset,
  message = 'Something went wrong in this section.',
}: InlineErrorFallbackProps) {
  return (
    <div
      role="alert"
      className="flex flex-col items-center gap-gf-md rounded-lg border border-red-200 bg-gf-status-danger-subtle p-gf-xl text-center dark:border-red-900"
    >
      <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
      <p className="text-sm text-gf-status-danger-fg">{message}</p>
      <button
        type="button"
        onClick={onReset}
        className="rounded-md bg-gf-status-danger-strong px-gf-md py-1.5 text-xs font-medium text-white hover:bg-red-700 transition-colors dark:hover:bg-red-600"
      >
        Try again
      </button>
    </div>
  );
}
