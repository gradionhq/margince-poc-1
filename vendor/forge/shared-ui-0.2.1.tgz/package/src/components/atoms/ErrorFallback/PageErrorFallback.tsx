import { AlertTriangle } from 'lucide-react';

export interface PageErrorFallbackProps {
  /** When provided, renders "Try again" instead of "Reload". */
  onReset?: () => void;
}

export function PageErrorFallback({ onReset }: PageErrorFallbackProps) {
  const handleClick = onReset ?? (() => window.location.reload());
  const buttonLabel = onReset ? 'Try again' : 'Reload';

  return (
    <div
      role="alert"
      className="flex h-full min-h-[300px] flex-col items-center justify-center gap-gf-lg p-gf-2xl text-center"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gf-status-danger-subtle">
        <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
      </div>
      <h2 className="text-lg font-semibold text-gf-primary">Something went wrong</h2>
      <p className="max-w-md text-sm text-gf-secondary">
        An unexpected error occurred.{' '}
        {onReset ? 'You can try again from here.' : 'You can reload the page to continue.'}
      </p>
      <button
        type="button"
        onClick={handleClick}
        className="mt-gf-sm rounded-lg bg-gf-accent px-gf-lg py-gf-sm text-sm font-medium text-white hover:bg-gf-accent/90 transition-colors"
      >
        {buttonLabel}
      </button>
    </div>
  );
}
