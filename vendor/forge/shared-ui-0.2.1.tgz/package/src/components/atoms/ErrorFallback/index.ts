export type { InlineErrorFallbackProps } from './InlineErrorFallback';
export { InlineErrorFallback } from './InlineErrorFallback';
export type { PageErrorFallbackProps } from './PageErrorFallback';
export { PageErrorFallback } from './PageErrorFallback';
