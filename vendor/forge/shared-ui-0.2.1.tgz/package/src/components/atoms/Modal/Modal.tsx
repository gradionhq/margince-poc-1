import { useEffect, useId, useRef } from 'react';
import type { ModalProps } from '../../../types/props';
import { IconButton } from '../IconButton/IconButton';

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  width = 'md',
  className = '',
  bodyClassName = '',
  noBorders = false,
}: ModalProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const titleId = useId();

  // showModal() puts the dialog in the top layer: native focus trap,
  // Escape-to-cancel, and immunity to ancestor transform/filter containing
  // blocks. The previous implementation portaled to document.body and
  // hand-rolled a Tab trap to work around a `transform` / `filter` on an
  // ancestor (virtualised lists, message-actions popover) trapping the
  // fixed-position backdrop — most visibly when a dialog opened from the
  // message ⋮ menu was pinned to the menu corner. The top layer makes the Tab
  // trap unnecessary.
  //
  // Focus restore stays manual: native focus restore only runs inside the
  // dialog's close() algorithm, but this component unmounts the <dialog> when
  // `open` flips false (see `if (!open) return null`), so close() never runs.
  // We capture the previously-focused element on open and restore it on
  // cleanup. We deliberately do NOT call dialog.close() here — closing via
  // onClick/onClose already sets open=false in the parent, and a manual close()
  // would dispatch the native `close` event and fire onClose a second time.
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      previousFocusRef.current = document.activeElement as HTMLElement | null;
      dialog.showModal();
    }
    return () => {
      // .focus() on a detached/null node is a safe no-op.
      previousFocusRef.current?.focus();
      previousFocusRef.current = null;
    };
  }, [open]);

  if (!open) return null;

  const widthClass = width === 'sm' ? 'max-w-md' : width === 'lg' ? 'max-w-xl' : 'max-w-lg';

  return (
    // biome-ignore lint/a11y/useKeyWithClickEvents: backdrop click dismiss; Escape is the native dialog cancel event wired through onClose
    <dialog
      ref={dialogRef}
      aria-labelledby={titleId}
      onClose={onClose}
      onClick={(e) => {
        // A click on ::backdrop targets the <dialog> element itself
        // (target === currentTarget). This requires the dialog to carry zero
        // padding — all padding lives on the inner header/body/footer divs.
        if (e.target === e.currentTarget) onClose();
      }}
      className={`m-auto flex w-[calc(100%-2rem)] flex-col rounded-2xl bg-gf-elevated p-0 shadow-[0_16px_48px_-8px_rgba(26,25,24,0.19)] border border-gf-subtle outline-none backdrop:bg-black/20 ${widthClass} ${bodyClassName ? '' : 'max-h-[85vh]'} ${className}`}
    >
      {/* Header */}
      <div
        className={`flex items-center justify-between px-gf-xl py-5 shrink-0 ${noBorders ? '' : 'border-b border-gf-subtle'}`}
      >
        <div className="flex flex-col gap-gf-xs">
          <h2 id={titleId} className="text-gf-heading font-bold text-gf-primary">
            {title}
          </h2>
          {subtitle && <p className="text-gf-caption text-gf-secondary">{subtitle}</p>}
        </div>
        <IconButton icon="X" label="Close" variant="ghost" size="sm" onClick={onClose} />
      </div>

      {/* Body */}
      {/* flex-auto (basis:auto) instead of flex-1 (basis:0%) fixes Safari: with basis=0% Safari
          collapses the body to zero height, making modal content invisible. */}
      <div className={`flex-auto min-h-0 ${bodyClassName || 'overflow-y-auto'}`}>{children}</div>

      {/* Footer */}
      {footer && (
        <div
          className={`flex items-center justify-end gap-gf-md px-gf-xl py-gf-lg shrink-0 ${noBorders ? '' : 'border-t border-gf-subtle'}`}
        >
          {footer}
        </div>
      )}
    </dialog>
  );
}
