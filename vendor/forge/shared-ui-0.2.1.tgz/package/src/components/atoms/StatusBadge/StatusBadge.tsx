import type { StatusBadgeProps } from '../../../types/props';

const variantClasses = {
  success: 'bg-gf-status-success-subtle text-gf-status-success-fg',
  warning: 'bg-yellow-100 text-yellow-700',
  error: 'bg-gf-status-danger-subtle text-gf-status-danger-fg',
  neutral: 'bg-gf-card text-gf-secondary',
  info: 'bg-gf-status-info-subtle text-gf-status-info-fg',
  accent: 'bg-gf-accent-light text-gf-accent',
} as const;

export function StatusBadge({ label, variant, className = '' }: StatusBadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${variantClasses[variant]} ${className}`}
    >
      {label}
    </span>
  );
}
