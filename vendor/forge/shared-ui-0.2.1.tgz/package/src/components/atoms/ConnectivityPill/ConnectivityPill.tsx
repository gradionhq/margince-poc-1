export type ConnectivityState = 'online' | 'offline' | 'reconnecting';

export interface ConnectivityPillProps {
  state: ConnectivityState;
  className?: string;
}

const STYLES: Record<
  Exclude<ConnectivityState, 'online'>,
  { cls: string; dot: string; label: string }
> = {
  offline: {
    cls: 'bg-gf-status-danger/10 text-red-600 border-gf-status-danger/30',
    dot: 'bg-gf-status-danger',
    label: 'Offline',
  },
  reconnecting: {
    cls: 'bg-gf-status-warning/10 text-gf-status-warning-fg border-gf-status-warning/30',
    dot: 'bg-gf-status-warning animate-pulse',
    label: 'Reconnecting',
  },
};

export function ConnectivityPill({ state, className = '' }: ConnectivityPillProps) {
  if (state === 'online') return null;
  const { cls, dot, label } = STYLES[state];
  return (
    // biome-ignore lint/a11y/useSemanticElements: span with role="status" is intentional for inline pill styling
    <span
      role="status"
      aria-live="polite"
      className={`inline-flex items-center gap-gf-sm px-gf-sm py-0.5 rounded-full border text-gf-micro font-medium leading-tight whitespace-nowrap ${cls} ${className}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
      {label}
    </span>
  );
}
