import { useEffect, useRef } from 'react';

export interface JsonEditorProps {
  value: string;
  onChange: (value: string) => void;
  onParsedChange?: (parsed: unknown | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
  rows?: number;
  className?: string;
  ariaLabel?: string;
}

interface ParseResult {
  parsed?: unknown;
  errorMessage?: string;
  errorLine?: number;
}

function parseJson(value: string): ParseResult {
  if (value.trim() === '') {
    return { parsed: undefined, errorMessage: undefined };
  }
  try {
    const parsed = JSON.parse(value);
    return { parsed };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    let errorLine: number | undefined;
    const lineMatch = message.match(/line\s+(\d+)/i);
    if (lineMatch) {
      errorLine = Number(lineMatch[1]);
    } else {
      const positionMatch = message.match(/position\s+(\d+)/i);
      if (positionMatch) {
        const position = Number(positionMatch[1]);
        errorLine = value.slice(0, position).split('\n').length;
      }
    }
    return { errorMessage: message, errorLine };
  }
}

export function JsonEditor({
  value,
  onChange,
  onParsedChange,
  placeholder,
  disabled = false,
  rows = 16,
  className = '',
  ariaLabel = 'JSON editor',
}: JsonEditorProps) {
  const { parsed, errorMessage, errorLine } = parseJson(value);
  const isValid = errorMessage === undefined;
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Notify parent of parsed result whenever value changes
  const lastParsedKey = useRef<string>('');
  useEffect(() => {
    if (!onParsedChange) return;
    const key = `${isValid ? '1' : '0'}:${value}`;
    if (lastParsedKey.current === key) return;
    lastParsedKey.current = key;
    onParsedChange(isValid ? parsed : undefined);
  }, [value, isValid, parsed, onParsedChange]);

  const handleFormat = () => {
    if (!isValid || parsed === undefined) return;
    const formatted = JSON.stringify(parsed, null, 2);
    if (formatted !== value) onChange(formatted);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const next = `${value.slice(0, start)}  ${value.slice(end)}`;
      onChange(next);
      // Restore caret after React updates value
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + 2;
          textareaRef.current.selectionEnd = start + 2;
        }
      });
    }
  };

  const errorText =
    errorMessage !== undefined
      ? errorLine !== undefined
        ? `Line ${errorLine}: ${errorMessage}`
        : errorMessage
      : null;

  return (
    <div className={`flex flex-col gap-gf-xs ${className}`}>
      <div className="flex items-center justify-end">
        <button
          type="button"
          onClick={handleFormat}
          disabled={disabled || !isValid || parsed === undefined}
          className="text-xs text-gf-secondary hover:text-gf-primary disabled:opacity-40 disabled:cursor-not-allowed px-gf-sm py-gf-xs rounded hover:bg-gf-elevated transition-colors"
        >
          Format
        </button>
      </div>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        rows={rows}
        disabled={disabled}
        aria-label={ariaLabel}
        aria-invalid={!isValid || undefined}
        spellCheck={false}
        className="w-full rounded-md bg-gf-elevated border border-gf-subtle text-xs font-mono text-gf-primary placeholder:text-gf-muted px-gf-md py-gf-sm transition-colors focus:border-gf-accent focus:ring-1 focus:ring-gf-accent focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed resize-y"
      />
      {errorText && (
        <div
          role="alert"
          className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-gf-sm py-gf-xs"
        >
          {errorText}
        </div>
      )}
    </div>
  );
}
