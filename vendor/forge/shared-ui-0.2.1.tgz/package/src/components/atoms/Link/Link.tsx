import type { LinkProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

const variantClasses = {
  default: 'text-gf-accent hover:underline',
  subtle: 'text-gf-secondary hover:text-gf-primary hover:underline',
} as const;

const sizeClasses = {
  sm: 'text-gf-small',
  md: 'text-gf-body',
  lg: 'text-gf-subheading',
} as const;

const iconSizes = {
  sm: 12,
  md: 16,
  lg: 18,
} as const;

export function Link({
  href,
  children,
  icon,
  className = '',
  external = false,
  variant = 'default',
  size = 'md',
}: LinkProps) {
  const externalProps = external ? { target: '_blank' as const, rel: 'noopener noreferrer' } : {};

  return (
    <a
      href={href}
      className={`inline-flex items-center gap-gf-xs ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...externalProps}
    >
      {children}
      {icon && <Icon name={icon} size={iconSizes[size]} />}
    </a>
  );
}
