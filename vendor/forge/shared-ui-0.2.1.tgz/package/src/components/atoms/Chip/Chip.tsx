import type { AgentName, ChipProps, ChipVariant } from '../../../types/props';
import { Icon } from '../Icon/Icon';

const accentBg: Record<AgentName, string> = {
  aria: 'bg-gf-agent-aria/15',
  pulse: 'bg-gf-agent-pulse/15',
  brief: 'bg-gf-agent-brief/15',
};

const accentFg: Record<AgentName, string> = {
  aria: 'text-gf-agent-aria',
  pulse: 'text-gf-agent-pulse',
  brief: 'text-gf-agent-brief',
};

const nonAccentClasses: Record<Exclude<ChipVariant, 'accent'>, string> = {
  neutral: 'bg-gf-card text-gf-secondary',
  success: 'bg-gf-agent-success/20 text-gf-agent-success-fg',
  danger: 'bg-gf-agent-danger/20 text-gf-agent-danger-fg',
  info: 'bg-gf-agent-info/20 text-gf-agent-info-fg',
};

export function Chip({
  variant = 'neutral',
  icon,
  agent = 'aria',
  mono,
  children,
  className = '',
}: ChipProps) {
  const isAccent = variant === 'accent';
  const colorClasses = isAccent
    ? `${accentBg[agent]} ${accentFg[agent]}`
    : nonAccentClasses[variant];

  // Default mono: true for neutral, false otherwise.
  const useMono = mono ?? variant === 'neutral';
  const fontClass = useMono ? 'font-mono font-medium' : 'font-semibold';
  const sizeClass = isAccent ? 'text-xs' : 'text-gf-micro';
  const iconSize = isAccent ? 12 : 11;

  return (
    <span
      data-testid="chip"
      data-variant={variant}
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-gf-xs ${sizeClass} ${fontClass} ${colorClasses} ${className}`}
    >
      {icon ? <Icon name={icon} size={iconSize} /> : null}
      {children}
    </span>
  );
}
