import type { PresenceIndicatorProps } from '../../../types/props';

const sizeClasses = {
  sm: 'h-2 w-2',
  md: 'h-2.5 w-2.5',
  lg: 'h-3.5 w-3.5',
} as const;

const statusClasses = {
  online: 'bg-gf-online',
  away: 'bg-gf-away',
  dnd: 'bg-gf-dnd',
  // Hollow circle: transparent fill + strong border. Used for the user's own
  // "offline" indicator AND for the new "invisible" self-view (MR-42 §42) —
  // both render the same so the user can see what peers see.
  offline: 'bg-gf-card border border-gf-strong',
  invisible: 'bg-gf-card border border-gf-strong',
} as const;

export function PresenceIndicator({ status, size = 'md', className = '' }: PresenceIndicatorProps) {
  return (
    <span
      data-testid="presence-indicator"
      data-status={status}
      className={`block rounded-full ring-2 ring-gf-page ${sizeClasses[size]} ${statusClasses[status]} ${className}`}
    />
  );
}
