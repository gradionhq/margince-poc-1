import type { SectionHeaderProps } from '../../../types/props';
import { Icon } from '../Icon/Icon';

export function SectionHeader({
  label,
  collapsed = false,
  onToggle,
  action,
  className = '',
}: SectionHeaderProps) {
  return (
    <div className={`flex items-center justify-between px-gf-xs ${className}`}>
      <button
        type="button"
        onClick={onToggle}
        className={`flex items-center gap-gf-xs text-gf-tertiary cursor-pointer ${onToggle ? 'hover:text-gf-secondary' : ''}`}
        disabled={!onToggle}
      >
        {onToggle && (
          <Icon
            name="ChevronDown"
            size={14}
            className={`transition-transform ${collapsed ? '-rotate-90' : ''}`}
          />
        )}
        <span className="text-gf-micro font-semibold tracking-[0.5px]">{label}</span>
      </button>
      {action && (
        <button
          type="button"
          onClick={action.onClick}
          aria-label={action.label}
          className="text-gf-tertiary hover:text-gf-secondary cursor-pointer"
        >
          <Icon name={action.icon} size={14} />
        </button>
      )}
    </div>
  );
}
