import { StatusEmoji } from './StatusEmoji';

interface StatusTooltipContentProps {
  emoji: string;
  imageUrl?: string;
  text?: string;
}

export function StatusTooltipContent({ emoji, imageUrl, text }: StatusTooltipContentProps) {
  return (
    <span className="flex flex-col items-center gap-1.5 px-gf-xs py-gf-xs">
      <span className="bg-white/10 rounded-md w-16 h-16 flex items-center justify-center overflow-hidden">
        <StatusEmoji emoji={emoji} imageUrl={imageUrl} className="text-[40px] leading-none" />
      </span>
      {text && (
        <span className="text-gf-small font-medium whitespace-normal text-center max-w-[200px]">
          {text}
        </span>
      )}
    </span>
  );
}
