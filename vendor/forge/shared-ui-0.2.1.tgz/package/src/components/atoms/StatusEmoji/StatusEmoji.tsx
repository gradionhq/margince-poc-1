interface StatusEmojiProps {
  emoji: string;
  imageUrl?: string;
  className?: string;
}

/**
 * Renders a status emoji — either as a unicode character or a custom emoji image.
 * When `imageUrl` is provided, renders an `<img>` sized to 1em (inherits from font-size on
 * the className), otherwise renders the raw text. This keeps unicode and custom emoji
 * visually consistent — change the size by adjusting font-size via `className`.
 * Returns null for unresolved custom emoji shortcodes (format :word:) to avoid showing broken text.
 */
export function StatusEmoji({
  emoji,
  imageUrl,
  className = 'text-gf-mini leading-none',
}: StatusEmojiProps) {
  if (!imageUrl && /^:.+:$/.test(emoji)) return null;

  if (imageUrl) {
    return (
      <span className={className} style={{ display: 'inline-flex', alignItems: 'center' }}>
        <img
          src={imageUrl}
          alt={emoji}
          style={{ width: '1em', height: '1em', objectFit: 'contain' }}
        />
      </span>
    );
  }
  return <span className={className}>{emoji}</span>;
}
