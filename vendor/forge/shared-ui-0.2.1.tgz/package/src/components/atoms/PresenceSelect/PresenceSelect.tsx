import { useCallback, useEffect, useRef, useState } from 'react';
import { Icon } from '../Icon/Icon';
import { PresenceIndicator } from '../PresenceIndicator/PresenceIndicator';

interface PresenceSelectProps {
  value: 'online' | 'away' | 'invisible';
  onChange: (status: 'online' | 'away' | 'invisible') => void;
  className?: string;
  testIdPrefix?: string;
}

const statusLabels = {
  online: 'Active',
  away: 'Away',
  invisible: 'Invisible',
} as const;

export function PresenceSelect({
  value,
  onChange,
  className = '',
  testIdPrefix = 'manual-status',
}: PresenceSelectProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleSelect = useCallback(
    (status: 'online' | 'away' | 'invisible') => {
      onChange(status);
      setOpen(false);
    },
    [onChange],
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLButtonElement>) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        setOpen((prev) => !prev);
      } else if (e.key === 'Escape' && open) {
        e.preventDefault();
        setOpen(false);
      }
    },
    [open],
  );

  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [open]);

  return (
    <div ref={containerRef} className={`relative inline-block ${className}`}>
      <button
        type="button"
        data-testid={`${testIdPrefix}-select`}
        onClick={() => setOpen((prev) => !prev)}
        onKeyDown={handleKeyDown}
        className="flex items-center gap-gf-sm px-gf-md py-gf-sm rounded-lg border border-gf-subtle hover:bg-gf-card/50 transition-colors cursor-pointer text-gf-primary"
      >
        <PresenceIndicator status={value} size="md" />
        <span className="text-gf-body">{statusLabels[value]}</span>
        <Icon name="ChevronDown" size={16} />
      </button>

      {open && (
        <ul
          role="listbox"
          className="absolute left-0 top-full z-gf-dropdown mt-gf-xs min-w-full rounded-lg border border-gf-subtle bg-gf-elevated shadow-lg"
        >
          {(['online', 'away', 'invisible'] as const).map((status) => (
            <li
              key={status}
              role="option"
              tabIndex={0}
              aria-selected={status === value}
              data-testid={`${testIdPrefix}-${status}`}
              className="cursor-pointer px-gf-md py-2.5 hover:bg-gf-card/50 transition-colors first:rounded-t-lg last:rounded-b-lg"
              onClick={() => handleSelect(status)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleSelect(status);
                }
              }}
            >
              <div className="flex items-center gap-2.5">
                <PresenceIndicator status={status} size="md" />
                <span className="text-gf-body flex-1 text-left">{statusLabels[status]}</span>
                {status === value && (
                  <span data-testid={`${testIdPrefix}-${status}-check`} className="inline-flex">
                    <Icon name="Check" size={16} className="text-gf-accent" />
                  </span>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
