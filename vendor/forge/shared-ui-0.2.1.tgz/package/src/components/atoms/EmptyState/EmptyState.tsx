import type { EmptyStateProps } from '../../../types/props';

export function EmptyState({ icon: Icon, title, description, className = '' }: EmptyStateProps) {
  return (
    <div
      className={`flex flex-col items-center justify-center gap-gf-sm py-gf-3xl text-center ${className}`}
    >
      <Icon className="h-10 w-10 text-gf-muted" />
      <p className="text-sm font-medium text-gf-secondary">{title}</p>
      {description && <p className="text-xs text-gf-tertiary">{description}</p>}
    </div>
  );
}
