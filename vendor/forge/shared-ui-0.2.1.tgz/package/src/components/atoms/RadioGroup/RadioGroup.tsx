import type { RadioGroupProps } from '../../../types/props';

export function RadioGroup({
  label,
  options,
  value,
  onChange,
  name,
  className = '',
}: RadioGroupProps) {
  return (
    <fieldset role="radiogroup" aria-label={label} className={`flex flex-col gap-gf-xs ${className}`}>
      <legend className="text-sm font-medium text-gf-primary mb-gf-sm">{label}</legend>
      {options.map((option) => (
        <label
          key={option.value}
          className="flex items-center gap-gf-md rounded-md px-gf-md py-gf-sm cursor-pointer hover:bg-gf-hover transition-colors text-sm text-gf-primary"
        >
          <input
            type="radio"
            name={name}
            value={option.value}
            checked={value === option.value}
            onChange={() => onChange(option.value)}
            className="w-4 h-4 accent-gf-accent"
          />
          {option.label}
        </label>
      ))}
    </fieldset>
  );
}
