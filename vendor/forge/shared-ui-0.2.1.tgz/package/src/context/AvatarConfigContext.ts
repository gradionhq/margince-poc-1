import { createContext } from 'react';

export interface AvatarConfig {
  baseUrl: string;
}

export const AvatarConfigContext = createContext<AvatarConfig>({ baseUrl: '' });
