import { createContext } from 'react';

export type AvatarBustGetter = (userId: string) => string | undefined;
export type AvatarBustSubscribe = (callback: () => void) => () => void;

export interface AvatarBustContextValue {
  getBust: AvatarBustGetter;
  subscribe: AvatarBustSubscribe;
}

export const AvatarBustContext = createContext<AvatarBustContextValue>({
  getBust: () => undefined,
  subscribe: () => () => {},
});
