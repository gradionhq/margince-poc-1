import { useCallback, useEffect, useRef, useState } from 'react';

export interface PanelResizeConfig {
  storageKey: string;
  defaultWidth: number;
  minWidth: number;
  maxWidth: number;
  /** When true, dragging left increases width (for right-anchored panels). Default false. */
  reverse?: boolean;
  /** When false, skip registering global mouse listeners. Default true. */
  enabled?: boolean;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function loadWidth(key: string, defaultWidth: number, min: number, max: number): number {
  try {
    const stored = localStorage.getItem(key);
    if (stored !== null) {
      const n = Number(stored);
      if (Number.isFinite(n)) return clamp(n, min, max);
    }
  } catch {
    // localStorage unavailable
  }
  return defaultWidth;
}

export function usePanelResize(config: PanelResizeConfig) {
  const { storageKey, defaultWidth, minWidth, maxWidth, reverse = false, enabled = true } = config;
  const [width, setWidth] = useState(() => loadWidth(storageKey, defaultWidth, minWidth, maxWidth));
  const widthRef = useRef(width);
  const dragging = useRef(false);
  const startX = useRef(0);
  const startWidth = useRef(0);

  const persistWidth = useCallback(
    (w: number) => {
      try {
        localStorage.setItem(storageKey, String(w));
      } catch {
        // localStorage unavailable
      }
    },
    [storageKey],
  );

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    dragging.current = true;
    startX.current = e.clientX;
    startWidth.current = widthRef.current;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  }, []);

  useEffect(() => {
    if (enabled === false) return;

    const onMouseMove = (e: MouseEvent) => {
      if (!dragging.current) return;
      const delta = e.clientX - startX.current;
      const newWidth = clamp(
        reverse ? startWidth.current - delta : startWidth.current + delta,
        minWidth,
        maxWidth,
      );
      widthRef.current = newWidth;
      setWidth(newWidth);
    };

    const onMouseUp = () => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      persistWidth(widthRef.current);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      if (dragging.current) {
        dragging.current = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
      }
    };
  }, [minWidth, maxWidth, reverse, persistWidth, enabled]);

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      const STEP = 10;
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        e.preventDefault();
        const increase = (e.key === 'ArrowRight') !== reverse;
        setWidth((w) => {
          const newWidth = clamp(w + (increase ? STEP : -STEP), minWidth, maxWidth);
          widthRef.current = newWidth;
          persistWidth(newWidth);
          return newWidth;
        });
      }
    },
    [reverse, minWidth, maxWidth, persistWidth],
  );

  return { width, onMouseDown, onKeyDown, minWidth, maxWidth };
}
