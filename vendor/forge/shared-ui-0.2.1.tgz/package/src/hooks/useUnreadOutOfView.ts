import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

/**
 * Target the hook recorded during the last `check()` so a later
 * `scrollToUnread()` call can re-resolve the DOM element. We never persist the
 * DOM Element itself — the sidebar mutates frequently (scroll virtualization,
 * presence updates, drafts, reordering) and a stored Element reference goes
 * stale in milliseconds.
 *
 * - `mainIndex`: row lives in the main Channels list at this ordered index.
 *   May be past `renderedCount`, in which case `ensureMainRendered` must be
 *   called first to mount it.
 * - `elementId`: row lives outside the main list (sectioned/starred/DM) — we
 *   address it by `data-channel-id` directly.
 */
type Target = { kind: 'mainIndex'; index: number; id: string } | { kind: 'elementId'; id: string };

/** Tiny breathing room so the target row doesn't sit flush against the top edge. */
const HEADER_OFFSET = 8;

export interface UseUnreadOutOfViewParams {
  scrollRef: React.RefObject<HTMLElement | null>;
  /**
   * Full ordered channel id list of the main Channels section, including the
   * un-rendered tail. Must use the same id basis as `data-channel-id` on
   * rendered rows (i.e. `channelUuid ?? id`).
   */
  mainChannelOrderedIds: string[];
  /** How many entries from `mainChannelOrderedIds` are currently rendered. */
  renderedCount: number;
  /** All unread channel ids (main + sectioned + starred + DMs). */
  unreadChannelIds: Set<string>;
  /**
   * Grow the render cap of the main Channels list so that the row at `minIndex`
   * mounts. Called when the user clicks the pill and the target is past
   * `renderedCount`.
   */
  ensureMainRendered: (minIndex: number) => void;
}

export interface UseUnreadOutOfViewResult {
  /** `'up'` / `'down'` if an unread row is out of view; `null` if all visible. */
  direction: 'up' | 'down' | null;
  /**
   * Scrolls the container so the nearest out-of-view unread row sits just
   * below the top edge. Re-resolves the DOM target on each call. If the row
   * is in the un-rendered tail, grows the render cap first and waits two
   * animation frames for React to mount it before scrolling.
   */
  scrollToUnread: () => void;
}

export function useUnreadOutOfView({
  scrollRef,
  mainChannelOrderedIds,
  renderedCount,
  unreadChannelIds,
  ensureMainRendered,
}: UseUnreadOutOfViewParams): UseUnreadOutOfViewResult {
  const [direction, setDirection] = useState<'up' | 'down' | null>(null);
  const targetRef = useRef<Target | null>(null);

  const indexOf = useMemo(() => {
    const map = new Map<string, number>();
    for (let i = 0; i < mainChannelOrderedIds.length; i++) {
      map.set(mainChannelOrderedIds[i], i);
    }
    return map;
  }, [mainChannelOrderedIds]);

  const check = useCallback(() => {
    const container = scrollRef.current;
    if (!container || unreadChannelIds.size === 0) {
      targetRef.current = null;
      setDirection(null);
      return;
    }

    const containerRect = container.getBoundingClientRect();

    // Track best "above" and "below" candidates.
    // For main-list rows: prefer the smallest index above (nearest to start)
    // and the smallest index below (nearest to viewport bottom — first unread
    // you'd hit scrolling down).
    let aboveMainIdx: number | null = null;
    let belowMainIdx: number | null = null;
    let aboveElId: string | null = null;
    let belowElId: string | null = null;
    let aboveElTop = Number.NEGATIVE_INFINITY; // highest top wins (closest to viewport top)
    let belowElTop = Number.POSITIVE_INFINITY; // lowest top wins (closest to viewport bottom)

    for (const id of unreadChannelIds) {
      const mainIdx = indexOf.get(id);
      if (mainIdx !== undefined && mainIdx >= renderedCount) {
        // Un-rendered tail. By construction this is below everything visible.
        if (belowMainIdx === null || mainIdx < belowMainIdx) {
          belowMainIdx = mainIdx;
        }
        continue;
      }

      const el = container.querySelector(`[data-channel-id="${id}"]`);
      if (!el) {
        // Element not in DOM (section collapsed). Parent section header shows
        // its own unread badge; skip.
        continue;
      }
      const elRect = el.getBoundingClientRect();
      const isAbove = elRect.bottom <= containerRect.top;
      const isBelow = elRect.top >= containerRect.bottom;
      if (!isAbove && !isBelow) continue; // visible

      if (mainIdx !== undefined) {
        if (isAbove) {
          if (aboveMainIdx === null || mainIdx > aboveMainIdx) aboveMainIdx = mainIdx;
        } else if (belowMainIdx === null || mainIdx < belowMainIdx) {
          belowMainIdx = mainIdx;
        }
      } else if (isAbove) {
        if (elRect.top > aboveElTop) {
          aboveElTop = elRect.top;
          aboveElId = id;
        }
      } else if (elRect.top < belowElTop) {
        belowElTop = elRect.top;
        belowElId = id;
      }
    }

    // Down is preferred — that's the original behavior and the common case.
    if (belowMainIdx !== null) {
      targetRef.current = {
        kind: 'mainIndex',
        index: belowMainIdx,
        id: mainChannelOrderedIds[belowMainIdx],
      };
      setDirection('down');
      return;
    }
    if (belowElId !== null) {
      targetRef.current = { kind: 'elementId', id: belowElId };
      setDirection('down');
      return;
    }
    if (aboveMainIdx !== null) {
      targetRef.current = {
        kind: 'mainIndex',
        index: aboveMainIdx,
        id: mainChannelOrderedIds[aboveMainIdx],
      };
      setDirection('up');
      return;
    }
    if (aboveElId !== null) {
      targetRef.current = { kind: 'elementId', id: aboveElId };
      setDirection('up');
      return;
    }
    targetRef.current = null;
    setDirection(null);
  }, [scrollRef, unreadChannelIds, indexOf, renderedCount, mainChannelOrderedIds]);

  // Keep the latest `check` accessible to the scroll listener without
  // re-attaching it on every input change. `unreadChannelIds` and
  // `mainChannelOrderedIds` identities churn on a hot path (presence/typing
  // updates), so we read `check` through a ref and re-run it via a separate
  // effect when its dependencies actually change.
  const checkRef = useRef(check);
  useEffect(() => {
    checkRef.current = check;
  }, [check]);

  useEffect(() => {
    check();
  }, [check]);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;

    let timeout: ReturnType<typeof setTimeout>;
    const handleScroll = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => checkRef.current(), 100);
    };

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      container.removeEventListener('scroll', handleScroll);
      clearTimeout(timeout);
    };
  }, [scrollRef]);

  const scrollToUnread = useCallback(() => {
    const container = scrollRef.current;
    const target = targetRef.current;
    if (!container || !target) return;

    const performScroll = (id: string) => {
      const el = container.querySelector(`[data-channel-id="${id}"]`);
      if (!el) return;
      const elRect = el.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const top = container.scrollTop + (elRect.top - containerRect.top) - HEADER_OFFSET;
      container.scrollTo({ top, behavior: 'smooth' });
    };

    if (target.kind === 'mainIndex' && target.index >= renderedCount) {
      ensureMainRendered(target.index);
      // Two RAFs: first lets React commit the new render cap, second lets
      // the layout settle before we measure.
      requestAnimationFrame(() => {
        requestAnimationFrame(() => performScroll(target.id));
      });
      return;
    }
    performScroll(target.id);
  }, [scrollRef, renderedCount, ensureMainRendered]);

  return { direction, scrollToUnread };
}
