import { useEffect } from 'react';

/**
 * Module-level counter for stacking scroll locks.
 * Multiple overlays (e.g. context menu + bottom sheet) can be open
 * simultaneously — body overflow is only restored when all unmount.
 */
let lockCount = 0;
let originalOverflow = '';

/**
 * Locks body scroll while the calling component is mounted.
 * Supports stacking: multiple concurrent locks are ref-counted.
 */
export function useScrollLock(enabled = true): void {
  useEffect(() => {
    if (!enabled) return;
    if (lockCount === 0) {
      originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
    }
    lockCount++;
    return () => {
      lockCount--;
      if (lockCount === 0) {
        document.body.style.overflow = originalOverflow;
      }
    };
  }, [enabled]);
}
