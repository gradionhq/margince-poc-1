import type React from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';

export interface LongPressPoint {
  x: number;
  y: number;
}

export interface UseLongPressOptions {
  onLongPress: (point: LongPressPoint) => void;
  /** Fires earlier than onLongPress for visual feedback (e.g. ripple). */
  onPrefireVisual?: (point: LongPressPoint) => void;
  ms?: number;
  /** Delay before onPrefireVisual fires. Ignored when onPrefireVisual is not set. */
  prefireMs?: number;
  moveThreshold?: number;
  enabled?: boolean;
  /** CSS selector for descendants that should never trigger a long-press. */
  ignoreSelector?: string;
}

export interface UseLongPressResult {
  ref: React.RefCallback<HTMLElement>;
  handlers: {
    onTouchMove: (e: React.TouchEvent) => void;
    onTouchEnd: () => void;
    onTouchCancel: () => void;
    onClickCapture: (e: React.MouseEvent) => void;
    onContextMenu: (e: React.MouseEvent) => void;
  };
}

const DEFAULT_IGNORE = 'a, button, input, textarea, [contenteditable="true"]';

/**
 * Touch-based long-press detection that also handles `contextmenu` for
 * Android/desktop. iOS Safari does not reliably fire `contextmenu` on touch
 * long-press, so we run a manual timer started on touchstart and cancel it on
 * movement or lift.
 *
 * Two-stage timing: when `onPrefireVisual` is provided, a shorter timer fires
 * first (at `prefireMs`, default 150ms) for early visual feedback (e.g. ripple),
 * then the main `onLongPress` fires at `ms` (default 950ms) to open the menu.
 */
export function useLongPress({
  onLongPress,
  onPrefireVisual,
  ms = 950,
  prefireMs = 150,
  moveThreshold = 10,
  enabled = true,
  ignoreSelector = DEFAULT_IGNORE,
}: UseLongPressOptions): UseLongPressResult {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prefireTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const firedRef = useRef(false);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const onLongPressRef = useRef(onLongPress);
  const onPrefireVisualRef = useRef(onPrefireVisual);
  useEffect(() => {
    onLongPressRef.current = onLongPress;
    onPrefireVisualRef.current = onPrefireVisual;
  });

  const cancel = useCallback(() => {
    if (prefireTimerRef.current) {
      clearTimeout(prefireTimerRef.current);
      prefireTimerRef.current = null;
    }
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => () => cancel(), [cancel]);

  const isInteractive = useCallback(
    (target: EventTarget | null) => {
      if (!ignoreSelector) return false;
      const el = target as HTMLElement | null;
      return Boolean(el?.closest(ignoreSelector));
    },
    [ignoreSelector],
  );

  const isInteractiveRef = useRef(isInteractive);
  isInteractiveRef.current = isInteractive;
  const msRef = useRef(ms);
  msRef.current = ms;
  const prefireMsRef = useRef(prefireMs);
  prefireMsRef.current = prefireMs;

  const [element, setElement] = useState<HTMLElement | null>(null);
  const ref = useCallback((node: HTMLElement | null) => {
    setElement(node);
  }, []);

  useEffect(() => {
    if (!element || !enabled) return;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      if (isInteractiveRef.current(e.target)) return;
      const t = e.touches[0];
      startPosRef.current = { x: t.clientX, y: t.clientY };
      firedRef.current = false;
      cancel();
      const startX = t.clientX;
      const startY = t.clientY;

      // Stage 1: early visual feedback (ripple) at prefireMs
      if (onPrefireVisualRef.current) {
        prefireTimerRef.current = setTimeout(() => {
          prefireTimerRef.current = null;
          onPrefireVisualRef.current?.({ x: startX, y: startY });
        }, prefireMsRef.current);
      }

      // Stage 2: main long-press action (menu open) at ms
      timerRef.current = setTimeout(() => {
        firedRef.current = true;
        onLongPressRef.current({ x: startX, y: startY });
      }, msRef.current);
    };

    // Block iOS selection/magnifier growth once long-press has fired.
    // Must be native { passive: false } — React synthetic handlers cannot
    // preventDefault on touchmove.
    const handleTouchMove = (e: TouchEvent) => {
      if (firedRef.current && e.cancelable) {
        e.preventDefault();
      }
    };

    element.addEventListener('touchstart', handleTouchStart, { passive: false });
    element.addEventListener('touchmove', handleTouchMove, { passive: false });
    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchmove', handleTouchMove);
    };
  }, [element, enabled, cancel]);

  const onTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if ((!timerRef.current && !prefireTimerRef.current) || !startPosRef.current) return;
      const t = e.touches[0];
      const dx = t.clientX - startPosRef.current.x;
      const dy = t.clientY - startPosRef.current.y;
      if (dx * dx + dy * dy > moveThreshold * moveThreshold) {
        cancel();
      }
    },
    [cancel, moveThreshold],
  );

  const onTouchEnd = useCallback(() => {
    cancel();
    startPosRef.current = null;
    // After a long-press fires, firedRef stays true to block the browser's
    // "ghost click" (synthesized ~0-300ms after touchend). Schedule a deferred
    // reset so that subsequent independent taps (e.g. on ActionSheet items
    // rendered in a portal) are NOT blocked by onClickCapture.
    if (firedRef.current) {
      setTimeout(() => {
        firedRef.current = false;
      }, 400);
    }
  }, [cancel]);

  const onClickCapture = useCallback((e: React.MouseEvent) => {
    if (firedRef.current) {
      e.preventDefault();
      e.stopPropagation();
      firedRef.current = false;
    }
  }, []);

  const onContextMenu = useCallback(
    (e: React.MouseEvent) => {
      if (!enabled) return;
      if (isInteractive(e.target)) return;
      e.preventDefault();
      if (firedRef.current) return;
      onLongPressRef.current({ x: e.clientX, y: e.clientY });
    },
    [enabled, isInteractive],
  );

  return {
    ref,
    handlers: {
      onTouchMove,
      onTouchEnd,
      onTouchCancel: onTouchEnd,
      onClickCapture,
      onContextMenu,
    },
  };
}
