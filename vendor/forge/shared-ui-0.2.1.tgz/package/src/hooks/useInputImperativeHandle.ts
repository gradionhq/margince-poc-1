import { useImperativeHandle } from 'react';
import type { InputHandle } from '../types/props';

/**
 * Expose a setText imperative handle so the parent can programmatically
 * update text and cursor position (e.g. after mention selection).
 */
export function useInputImperativeHandle(
  inputRef: React.RefObject<InputHandle | null> | undefined,
  textareaRef: React.RefObject<HTMLTextAreaElement | null>,
  setText: (text: string) => void,
  onTextChange?: (markdown: string, plainText: string, cursorPosition: number) => void,
) {
  useImperativeHandle(inputRef, () => ({
    setText: (newText: string, cursorPosition: number) => {
      setText(newText);
      onTextChange?.(newText, newText, cursorPosition);
      requestAnimationFrame(() => {
        const el = textareaRef.current;
        if (el) {
          el.setSelectionRange(cursorPosition, cursorPosition);
          el.focus();
        }
      });
    },
    insertAtCursor: (text: string) => {
      const el = textareaRef.current;
      if (!el) return;
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? start;
      const before = el.value.slice(0, start);
      const after = el.value.slice(end);
      const newText = `${before}${text}${after}`;
      const newCursor = start + text.length;
      setText(newText);
      onTextChange?.(newText, newText, newCursor);
      requestAnimationFrame(() => {
        el.setSelectionRange(newCursor, newCursor);
        el.focus();
      });
    },
  }));
}
