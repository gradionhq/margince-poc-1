import type { RefObject } from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';

const BOTTOM_THRESHOLD = 50;

export interface UseScrollToBottomOptions {
  scrollRef: RefObject<HTMLElement | null>;
  messagesLength: number;
  /** ID of the last (newest) message. Used to detect real-time appends vs. pagination prepends. */
  lastMessageId: string | undefined;
}

export interface UseScrollToBottomReturn {
  isAtBottom: boolean;
  newMessageCount: number;
  /** Number of messages to highlight after the last scrollToBottom call. Resets to 0 after reading. */
  highlightNewCount: number;
  scrollToBottom: () => void;
}

export function useScrollToBottom({
  scrollRef,
  messagesLength,
  lastMessageId,
}: UseScrollToBottomOptions): UseScrollToBottomReturn {
  const [isAtBottom, setIsAtBottom] = useState(true);
  const [newMessageCount, setNewMessageCount] = useState(0);
  const [highlightNewCount, setHighlightNewCount] = useState(0);
  const prevMessagesLengthRef = useRef(messagesLength);
  const prevLastMessageIdRef = useRef(lastMessageId);
  const isAtBottomRef = useRef(true);

  // Track scroll position
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    function handleScroll() {
      if (!el) return;
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - BOTTOM_THRESHOLD;
      isAtBottomRef.current = atBottom;
      setIsAtBottom(atBottom);
      if (atBottom) {
        setNewMessageCount(0);
      }
    }

    el.addEventListener('scroll', handleScroll, { passive: true });
    return () => el.removeEventListener('scroll', handleScroll);
  }, [scrollRef]);

  // Handle new messages appended at the end (real-time).
  // Pagination loads (older messages prepended) change messagesLength but
  // don't change lastMessageId — so they are ignored.
  useEffect(() => {
    const prevLen = prevMessagesLengthRef.current;
    const diff = messagesLength - prevLen;
    const lastIdChanged = lastMessageId !== prevLastMessageIdRef.current;
    // Skip the initial 0 → N load — that's the first render, not a realtime append.
    // Caller owns initial positioning (e.g. deep-link scrollIntoView).
    if (prevLen > 0 && diff > 0 && lastIdChanged) {
      if (isAtBottomRef.current) {
        // Auto-scroll to bottom so new replies are immediately visible
        const el = scrollRef.current;
        if (el) {
          el.scrollTop = el.scrollHeight;
        }
      } else {
        setNewMessageCount((prev) => prev + diff);
      }
    }
    prevMessagesLengthRef.current = messagesLength;
    prevLastMessageIdRef.current = lastMessageId;
  }, [messagesLength, lastMessageId, scrollRef]);

  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current;
    if (el) {
      // Capture count before resetting so MessageList can highlight
      setHighlightNewCount(newMessageCount);
      el.scrollTop = el.scrollHeight;
    }
  }, [scrollRef, newMessageCount]);

  return { isAtBottom, newMessageCount, highlightNewCount, scrollToBottom };
}
