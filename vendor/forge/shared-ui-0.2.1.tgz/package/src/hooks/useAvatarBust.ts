import { useContext, useSyncExternalStore } from 'react';
import { AvatarBustContext } from '../context/AvatarBustContext';

export function useAvatarBust(
  userId: string | undefined,
  explicitBust: string | undefined,
): string | undefined {
  const { getBust, subscribe } = useContext(AvatarBustContext);
  const bust = useSyncExternalStore(subscribe, () => (userId ? getBust(userId) : undefined));
  if (explicitBust) return explicitBust;
  return bust;
}
