import { useEffect, useState } from 'react';

const MOBILE_QUERY = '(max-width: 767px)';

/**
 * Single source of truth for "is the current viewport a mobile-sized screen?".
 *
 * Viewport-based: matches when screen width ≤ 767px. Use this for layout
 * branching (sidebar vs fullscreen, popover vs bottom-sheet, default toolbar
 * collapsed, etc.).
 *
 * For touch-vs-mouse detection (e.g., long-press triggers), prefer a
 * `(pointer: coarse)` check instead — a tablet has coarse pointer + wide
 * viewport.
 */
export function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = useState(() =>
    typeof window === 'undefined' ? false : window.matchMedia(MOBILE_QUERY).matches,
  );

  useEffect(() => {
    const mql = window.matchMedia(MOBILE_QUERY);
    const handler = (e: MediaQueryListEvent) => setIsMobile(e.matches);
    setIsMobile(mql.matches);
    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, []);

  return isMobile;
}
