// Component prop interfaces for forge-components.
// Each component imports its props from this module to ensure a single source of truth.
//
// Scope: only types referenced by components that ship from this package.
// Workspace-specific domain types (MessageBubble, ChannelSidebar, Thread*, etc.)
// previously lived here but were removed in 0.4.0 — domain components live in
// the workspace `gw-ui` package now. If you add a new shipped component, add
// its prop interface here; if you remove one, drop the interface too.

import type { ComponentType, ReactNode } from 'react';

// FeatureFlags is a product-feature concern (which workspace features exist),
// not a generic design-system primitive — it lives in the consuming app
// (gw-ui) rather than this package.

// ── Atom Props ──

export type ToastVariant = 'success' | 'error' | 'warning' | 'info';

export interface ToastProps {
  id: string;
  variant: ToastVariant;
  title: string;
  message?: string;
  onClose?: (id: string) => void;
}

export interface AvatarProps {
  name: string;
  avatarUrl?: string;
  userId?: string;
  hasAvatar?: boolean;
  avatarBustParam?: string;
  avatarBaseUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'profile';
  color?: string;
  onAvatarClick?: () => void;
  className?: string;
  /** When true, renders BotAvatar instead of the normal user avatar */
  isBot?: boolean;
}

export interface BadgeProps {
  count: number;
  max?: number;
  variant?: 'default' | 'dot';
}

export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'accent-outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  icon?: string;
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  loading?: boolean;
  className?: string;
  type?: 'button' | 'submit' | 'reset';
  'data-testid'?: string;
}

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  /** sm = max-w-md (448px), md = max-w-lg (512px), lg = max-w-xl (576px) */
  width?: 'sm' | 'md' | 'lg';
  className?: string;
  /** Additional class for the scrollable body container (e.g. "overflow-visible" for dropdowns) */
  bodyClassName?: string;
  /** When true, removes header and footer border separators for a cleaner look. */
  noBorders?: boolean;
}

export interface RadioGroupProps {
  label: string;
  options: { value: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
  name: string;
  className?: string;
}

export interface DividerProps {
  orientation?: 'horizontal' | 'vertical';
  className?: string;
}

export interface IconProps {
  name: string;
  size?: number;
  className?: string;
}

export interface ThemeCardProps {
  variant: 'light' | 'dark' | 'system';
  selected: boolean;
  onClick: () => void;
  label: string;
}

export interface IconButtonProps {
  icon: string;
  onClick?: () => void;
  label: string;
  variant?: 'default' | 'ghost';
  size?: 'sm' | 'md';
  className?: string;
  disabled?: boolean;
}

export interface KbdProps {
  keys: string[];
  className?: string;
}

export interface LinkProps {
  href: string;
  children: ReactNode;
  icon?: string;
  className?: string;
  external?: boolean;
  /** Visual emphasis. `default` = accent-colored, `subtle` = secondary-colored,
   *  underline on hover only. */
  variant?: 'default' | 'subtle';
  /** Type size — maps to text-gf-body / text-gf-caption / text-gf-small. */
  size?: 'sm' | 'md' | 'lg';
}

export interface PresenceIndicatorProps {
  /**
   * Manual or resolved presence status.
   *
   * "invisible" is only ever rendered for the current user's self-view —
   * peers see invisible users as "offline" (MR-42 §42). Visually it matches
   * "offline" (hollow circle: transparent fill + strong border).
   */
  status: 'online' | 'away' | 'dnd' | 'offline' | 'invisible';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export interface SkeletonProps {
  variant?: 'circle' | 'bar' | 'block';
  width?: string;
  height?: string;
  /** Aspect ratio for `variant="block"` — passes through to CSS `aspect-ratio`.
   *  Example: `aspectRatio="16/9"` for a video placeholder. */
  aspectRatio?: string;
  className?: string;
}

export interface TextInputProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onKeyDown?: (e: React.KeyboardEvent) => void;
  leadingIcon?: string;
  trailingIcon?: string;
  className?: string;
  disabled?: boolean;
  type?: string;
}

export interface TooltipProps {
  content: React.ReactNode;
  children: ReactNode;
  side?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
}

export interface SectionHeaderProps {
  label: string;
  collapsed?: boolean;
  onToggle?: () => void;
  action?: { icon: string; label: string; onClick: () => void };
  className?: string;
}

// ── AI / Agent Atom Props ──

export type AgentName = 'aria' | 'pulse' | 'brief';
export type AgentTone = AgentName | 'success' | 'danger' | 'info' | 'neutral';

export type StatusDotState = 'running' | 'success' | 'error';
export interface StatusDotProps {
  state: StatusDotState;
  className?: string;
  /** Dot size. `sm` (8px, default) for inline use; `md` / `lg` for emphasis. */
  size?: 'sm' | 'md' | 'lg';
  /** Accessible label for screen readers (default derived from state). */
  ariaLabel?: string;
}

export type ChipVariant = 'accent' | 'neutral' | 'success' | 'danger' | 'info';
export interface ChipProps {
  variant?: ChipVariant; // default 'neutral'
  /** Optional lucide icon name (rendered via Icon atom). */
  icon?: string;
  /** Tone override for `accent` variant. Default 'aria'. Ignored for non-accent variants. */
  agent?: AgentName;
  /** Render text in monospace font (default true for `neutral`, false otherwise). */
  mono?: boolean;
  children: ReactNode;
  className?: string;
}

/** Imperative handle exposed by message input components for programmatic text/cursor control */
export interface InputHandle {
  setText: (text: string, cursorPosition: number) => void;
  insertAtCursor: (text: string) => void;
  insertCustomEmoji?: (name: string, imageUrl: string) => void;
  /** Replace N characters before the cursor with replacement text (preserves formatting) */
  replaceBeforeCursor?: (deleteCount: number, replacement: string) => void;
  /** Replace N characters before the cursor with a custom emoji image (preserves formatting) */
  replaceBeforeCursorWithEmoji?: (deleteCount: number, name: string, imageUrl: string) => void;
  /** Replace N characters before the cursor with a mention node */
  insertMention?: (deleteCount: number, userId: string, displayName: string) => void;
}

// ── Admin Atom Props ──

export type BadgeVariant = 'success' | 'warning' | 'error' | 'neutral' | 'info' | 'accent';

export interface StatusBadgeProps {
  label: string;
  variant: BadgeVariant;
  className?: string;
}

export interface FilterDropdownOption {
  label: string;
  value: string;
}

export interface FilterDropdownProps {
  label: string;
  value: string;
  options: FilterDropdownOption[];
  onChange: (value: string) => void;
  className?: string;
}

export interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  confirmVariant?: 'primary' | 'destructive';
  requireConfirmText?: string;
  isLoading?: boolean;
}

// ── Empty State ──

export interface EmptyStateProps {
  icon: ComponentType<{ className?: string }>;
  title: string;
  description?: string;
  className?: string;
}
