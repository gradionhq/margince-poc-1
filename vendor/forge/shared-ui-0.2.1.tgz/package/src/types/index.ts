// Component view-model types and prop interfaces (local to gw-ui)
// API types live in @gradion/contracts — import them directly in gw-web.

export type { CustomEmoji } from './custom-emoji';
export * from './props';
