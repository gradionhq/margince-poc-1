// CustomEmoji shape consumed by status-emoji resolution (resolveStatusEmojiUrl).
// Defined locally so the package stays self-contained and free of any
// workspace API contract (@gradion/contracts). The consuming app's
// `@gradion/contracts` CustomEmoji is structurally identical, so passing it
// where this type is expected type-checks via structural typing.
export interface CustomEmoji {
  id: string;
  workspace_id: string;
  name: string;
  image_url: string;
  content_type: string;
  file_size: number;
  uploaded_by: string;
  created_at: string;
}
