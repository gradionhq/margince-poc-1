# @shared/ui

Atoms-only headless React UI primitives (Button, Avatar, Badge, Chip, Toast, ...). Generic building blocks only: domain components (message bubbles, channel sidebars) live in the consuming app.

Ported from [forge-design-system](https://git.nfq.asia/josh.ziethen/forge-design-system) `@josh.ziethen/forge-components` 0.10.0. The forge repo stays as dev/backup home (tests, stories, full toolchain).

## Usage

```ts
import { Button, Avatar } from '@shared/ui';
import '@shared/ui/index.css'; // pulls @shared/token CSS vars + Tailwind theme
```

Peer deps: `react`, `react-dom` (18 or 19), `@shared/token`.

## Notes

- **Source publish**: ships raw TypeScript/TSX (`main: ./src/index.ts`). Consumers compile with their own toolchain. No `dist/`.
- Styling via `@shared/token` Tailwind utilities. No inline hex, no raw Tailwind palette refs.
- Self-contained: no dependency on any workspace contract. The `CustomEmoji` shape used by status-emoji resolution is defined locally in `src/types/custom-emoji.ts` (structurally identical to the consuming app's `@gradion/contracts` `CustomEmoji`).
- Tests and Storybook stories are not ported. They live in the forge repo.
