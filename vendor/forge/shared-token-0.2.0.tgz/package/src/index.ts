// Theme hook
export type { ThemeTokens } from './hooks/useThemeTokens';
export { getThemeTokens } from './hooks/useThemeTokens';
// Mobile tokens (TS-only; Tailwind handles equivalent on web)
export {
  avatarFontSizes,
  avatarSizes,
  badgeMaxCount,
  badgeMinWidth,
  brandShadows,
  buttonSizes,
  fontFamilies,
  iconSizes,
  presenceDotSizes,
  radii,
  shadows,
  spacing,
} from './tokens/mobile';
export type { ColorKey } from './tokens/shared';
// Shared tokens (round-trips web ↔ mobile)
export { darkColors, lightColors } from './tokens/shared';
// Web token types (consumers use @gradion/design-system/tokens/web for values)
export type { RadiusKey, TextVariantKey } from './tokens/web';
export { textVariants } from './tokens/web';

// Component prop contracts (Button/Avatar/MessageBubble/... base props) are a
// product/UI concern, not a design token — they live in the consuming app
// (gw-design-system, re-exported to gw-ui + gw-mobile-ui), not this package.
