/**
 * Resolved color values for programmatic use — Reanimated interpolations,
 * SVG fill colors, dynamic StatusBar color, etc.
 *
 * Prefer `className` for all styling. Use this only when className can't work.
 */
import { darkColors, lightColors } from '../tokens/shared/colors';

export interface ThemeTokens {
  bgPage: string;
  bgElevated: string;
  bgCard: string;
  bgHover: string;
  accent: string;
  accentLight: string;
  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  textMuted: string;
  textOnAccent: string;
  borderSubtle: string;
  borderStrong: string;
  online: string;
  teal: string;
  unreadBadge: string;
  away: string;
  dnd: string;
  dangerText: string;
  bgTooltip: string;
  textTooltip: string;
  gradientStart: string;
  gradientEnd: string;
  googleBlue: string;
}

/** Returns theme tokens for the given color scheme. Platform-agnostic. */
export function getThemeTokens(colorScheme: 'light' | 'dark' | null | undefined): ThemeTokens {
  return colorScheme === 'dark' ? darkColors : lightColors;
}
