#!/usr/bin/env tsx
/**
 * Design-system drift check.
 *
 * Compares the shared color subset between TypeScript (`tokens/shared/colors.ts`)
 * and CSS (`tokens/web/variables.css`). Fails CI when values diverge.
 *
 * Scope: shared colors only. Typography, radii, shadows, sizing are intentionally
 * disjoint surfaces — no drift to check there.
 */

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { darkColors, lightColors } from '../tokens/shared/colors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CSS_PATH = join(__dirname, '..', 'tokens', 'web', 'variables.css');
const CSS_PREFIX = '--gf-';

/**
 * Mapping table — TS key (camelCase) ↔ CSS variable suffix (kebab-case, after `--gf-`).
 *
 * Explicit, not inferred. Renames are caught: drop a key here and the check fails
 * before the CSS rename ships. Add a key only with design + doc sign-off.
 */
const MAPPING: Record<keyof typeof lightColors, string> = {
  bgPage: 'bg-page',
  bgElevated: 'bg-elevated',
  bgCard: 'bg-card',
  bgHover: 'bg-hover',
  accent: 'accent',
  accentLight: 'accent-light',
  textPrimary: 'text-primary',
  textSecondary: 'text-secondary',
  textTertiary: 'text-tertiary',
  textMuted: 'text-muted',
  textOnAccent: 'text-on-accent',
  borderSubtle: 'border-subtle',
  borderStrong: 'border-strong',
  online: 'online',
  teal: 'teal',
  unreadBadge: 'unread-badge',
  away: 'away',
  dnd: 'dnd',
  dangerText: 'danger-text',
  bgTooltip: 'bg-tooltip',
  textTooltip: 'text-tooltip',
  gradientStart: 'gradient-start',
  gradientEnd: 'gradient-end',
  googleBlue: 'google-blue',
};

interface ParsedCSS {
  light: Record<string, string>;
  dark: Record<string, string>;
}

/**
 * Parse `:root { … }` and `.dark { … }` blocks from a CSS string. Keys keep the
 * `--gf-` prefix removed; values are returned verbatim (normalization happens
 * later, at comparison time).
 */
export function parseCSS(content: string): ParsedCSS {
  const result: ParsedCSS = { light: {}, dark: {} };
  // Strip comments first — a `}` inside a comment would otherwise truncate
  // the enclosing block at the [^}]* boundary.
  const stripped = content.replace(/\/\*[\s\S]*?\*\//g, '');
  const blockRegex = /(:root|\.dark)\s*\{([^}]*)\}/g;
  for (const match of stripped.matchAll(blockRegex)) {
    const selector = match[1];
    const body = match[2];
    const target = selector === ':root' ? result.light : result.dark;
    const declRegex = /--gf-([a-z0-9-]+)\s*:\s*([^;]+);/g;
    for (const decl of body.matchAll(declRegex)) {
      target[decl[1]] = decl[2].trim();
    }
  }
  return result;
}

/**
 * Resolve a CSS value to a comparable color literal within a variable scope.
 *
 * - `var(--gf-x)` references resolve recursively against `scope` (suffix keys,
 *   prefix already stripped). Unresolvable references are returned untouched
 *   so the drift error shows the raw value.
 * - `color-mix(in srgb, C p%, transparent)` → `rgba(r, g, b, p/100)`
 * - `color-mix(in srgb, C1 p%, C2)` → weighted sRGB blend of two opaque hexes
 *
 * Only the color-mix forms actually used in variables.css are evaluated;
 * anything else passes through and surfaces as a drift error for human eyes.
 */
export function resolveValue(value: string, scope: Record<string, string>): string {
  let v = value.trim();
  // Chase var() chains (bounded to avoid reference cycles)
  for (let i = 0; i < 8; i++) {
    const varMatch = v.match(/^var\(--gf-([a-z0-9-]+)\)$/);
    if (!varMatch) break;
    const next = scope[varMatch[1]];
    if (next === undefined) return v;
    v = next.trim();
  }
  const mix = v.match(/^color-mix\(in srgb,\s*(.+?)\s+(\d+(?:\.\d+)?)%\s*,\s*(.+?)\s*\)$/);
  if (mix) {
    const c1 = hexToRgb(resolveValue(mix[1], scope));
    const weight = Number(mix[2]) / 100;
    if (c1) {
      if (mix[3] === 'transparent') {
        return `rgba(${c1.r}, ${c1.g}, ${c1.b}, ${weight})`;
      }
      const c2 = hexToRgb(resolveValue(mix[3], scope));
      if (c2) {
        const blend = (a: number, b: number) => Math.round(a * weight + b * (1 - weight));
        return rgbToHex(blend(c1.r, c2.r), blend(c1.g, c2.g), blend(c1.b, c2.b));
      }
    }
  }
  return v;
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const m = hex.trim().match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = Number.parseInt(m[1], 16);
  return { r: (n >> 16) & 0xff, g: (n >> 8) & 0xff, b: n & 0xff };
}

function rgbToHex(r: number, g: number, b: number): string {
  return `#${[r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('')}`;
}

/**
 * Normalize a color value so equivalent representations compare equal.
 *
 * - Lowercase
 * - Expand 3-digit hex (`#fff` → `#ffffff`)
 * - Collapse rgb/rgba whitespace; uniform decimals
 */
export function normalize(value: string): string {
  let v = value.trim().toLowerCase();
  // Expand 3-digit hex to 6-digit
  const shortHex = v.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/);
  if (shortHex) {
    v = `#${shortHex[1]}${shortHex[1]}${shortHex[2]}${shortHex[2]}${shortHex[3]}${shortHex[3]}`;
  }
  // Normalize rgb()/rgba() — strip whitespace, normalize alpha precision
  const rgbMatch = v.match(/^rgba?\(([^)]+)\)$/);
  if (rgbMatch) {
    const parts = rgbMatch[1].split(',').map((p) => {
      const t = p.trim();
      // Numbers (alpha) → standard precision via Number → string
      const n = Number(t);
      return Number.isFinite(n) && t.includes('.') ? String(n) : t;
    });
    v = `rgba(${parts.join(', ')})`;
    // Collapse rgba(...,1) → rgb(...) for opaque
    v = v.replace(/^rgba\(([^,]+,[^,]+,[^,]+),\s*1\)$/, 'rgb($1)');
  }
  return v;
}

interface CheckResult {
  errors: string[];
  warnings: string[];
}

export function check(parsed: ParsedCSS): CheckResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  const cssKeysExpected = new Set<string>();
  for (const [tsKey, cssSuffix] of Object.entries(MAPPING) as Array<
    [keyof typeof lightColors, string]
  >) {
    cssKeysExpected.add(cssSuffix);
    for (const mode of ['light', 'dark'] as const) {
      const tsValue = mode === 'light' ? lightColors[tsKey] : darkColors[tsKey];
      const cssValue = parsed[mode][cssSuffix];
      if (cssValue === undefined) {
        errors.push(
          `[${mode}] missing CSS variable ${CSS_PREFIX}${cssSuffix} (expected to mirror TS \`${tsKey}\`)`,
        );
        continue;
      }
      // CSS cascade: in .dark context, var() falls back to :root for
      // variables the .dark block doesn't redefine.
      const scope = mode === 'light' ? parsed.light : { ...parsed.light, ...parsed.dark };
      const resolved = resolveValue(cssValue, scope);
      if (normalize(resolved) !== normalize(tsValue)) {
        errors.push(
          `[${mode}] ${tsKey} drift: TS = ${tsValue} | CSS ${CSS_PREFIX}${cssSuffix} = ${cssValue}${
            resolved !== cssValue ? ` (resolves to ${resolved})` : ''
          }`,
        );
      }
    }
    if (!(tsKey in lightColors) || !(tsKey in darkColors)) {
      errors.push(`TS missing key \`${tsKey}\` from lightColors or darkColors`);
    }
  }

  // Unmapped CSS keys → warning (could be intentional web-only, or a forgotten mapping)
  for (const mode of ['light', 'dark'] as const) {
    for (const cssSuffix of Object.keys(parsed[mode])) {
      if (!cssKeysExpected.has(cssSuffix) && !isWebOnlyKey(cssSuffix)) {
        warnings.push(
          `[${mode}] unmapped CSS variable ${CSS_PREFIX}${cssSuffix} — add to MAPPING or document as web-only`,
        );
      }
    }
  }

  return { errors, warnings };
}

/**
 * CSS variables intentionally web-only (no mobile counterpart). Listed explicitly
 * so a typo or new accidental drift surfaces as a warning.
 */
function isWebOnlyKey(cssSuffix: string): boolean {
  if (cssSuffix === 'text-content' || cssSuffix === 'bg-rail') return true;
  // Palette scale primaries (--gf-red-500, --gf-neutral-50, …) — the L1 layer
  // semantic tokens route through. Web-only by design; mobile consumes the
  // resolved semantic values from colors.ts.
  if (/^(neutral|stone|red|amber|yellow|green|blue|teal|orange|pink|rose|violet)-\d+$/.test(cssSuffix)) {
    return true;
  }
  if (cssSuffix === 'white' || cssSuffix === 'black') return true;
  if (cssSuffix.startsWith('font-')) return true;
  if (cssSuffix.startsWith('text-') && /-(size|weight|line-height)$/.test(cssSuffix)) return true;
  if (cssSuffix.startsWith('radius-')) return true;
  // Agent slot palette — fixed colors, never theme-shifted; mobile uses its own constants.
  if (cssSuffix.startsWith('agent-')) return true;
  // Semantic status — aliases for the agent-* status values, but exposed under a
  // non-agent-specific namespace. Same values; different name.
  if (cssSuffix.startsWith('status-')) return true;
  // Page-level layout primitives — max-widths and gutters. Web-only by nature.
  if (cssSuffix.startsWith('layout-')) return true;
  // Tailwind max-w-* container scale override (forge 0.2.x). Web-only.
  if (cssSuffix.startsWith('container-')) return true;
  // Progress track background — web-only component surface.
  if (cssSuffix === 'bg-progress-track') return true;
  // L3 component-specific dimensions (avatar sizes, menu widths, derived indents).
  if (cssSuffix.startsWith('component-')) return true;
  // Token categories added to extend the web surface beyond colors. No mobile
  // counterpart yet; mobile owns its own sizing / motion / shadow constants.
  if (cssSuffix.startsWith('space-')) return true;
  if (cssSuffix.startsWith('spacing-')) return true;
  if (cssSuffix.startsWith('shadow-')) return true;
  if (cssSuffix.startsWith('dur-') || cssSuffix.startsWith('ease-')) return true;
  if (cssSuffix.startsWith('z-')) return true;
  if (cssSuffix.startsWith('bp-')) return true;
  return false;
}

function main(): void {
  const cssContent = readFileSync(CSS_PATH, 'utf-8');
  const parsed = parseCSS(cssContent);
  const { errors, warnings } = check(parsed);

  for (const w of warnings) console.warn(`⚠️  ${w}`);
  for (const e of errors) console.error(`❌ ${e}`);

  if (errors.length > 0) {
    console.error('\n→ See docs/design-system.md "How drift check works" for resolution');
    process.exit(1);
  }
  console.log(
    `✓ Design system in sync (${Object.keys(MAPPING).length} keys × 2 modes${
      warnings.length > 0 ? `, ${warnings.length} warnings` : ''
    })`,
  );
}

// Only run when invoked directly as a script (not when imported by tests)
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
