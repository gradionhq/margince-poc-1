/**
 * Shared color palette — round-trips between web CSS variables and mobile TS objects.
 *
 * This is the only token surface where web and mobile must stay in sync.
 * The drift-check tool (`gf-ds-check`) enforces equality between this file
 * and `../web/variables.css` for every key in the mapping table.
 *
 * Adding a new color:
 *   1. Add to both `lightColors` and `darkColors` here
 *   2. Mirror in `../web/variables.css` (`:root` and `.dark` blocks)
 *   3. Add an entry to `../../cli/check.ts` MAPPING table
 *   4. Run `make ds-check` — must pass
 */

export const lightColors = {
  bgPage: '#fafaf9',
  bgElevated: '#ffffff',
  bgCard: '#f1f1f1',
  bgHover: '#f5f4f3',
  accent: '#ff6b00',
  accentLight: 'rgba(255, 107, 0, 0.08)',
  textPrimary: '#292524',
  textSecondary: '#78716c',
  textTertiary: '#a8a29e',
  textMuted: '#d6d3d1',
  textOnAccent: '#ffffff',
  borderSubtle: '#e7e5e4',
  borderStrong: '#d6d3d1',
  online: '#22c55e',
  teal: '#0d9488',
  unreadBadge: '#ff6b00',
  away: '#fbbf24',
  dnd: '#ef4444',
  dangerText: '#dc2626',
  bgTooltip: '#292524',
  textTooltip: '#ffffff',
  gradientStart: '#ea580c',
  gradientEnd: '#d97706',
  googleBlue: '#4285f4',
} as const;

export const darkColors = {
  bgPage: '#1c1917',
  bgElevated: '#292524',
  bgCard: '#44403c',
  bgHover: '#373230',
  accent: '#ff8c2b',
  accentLight: 'rgba(255, 140, 43, 0.13)',
  textPrimary: '#fafaf9',
  textSecondary: '#a8a29e',
  textTertiary: '#78716c',
  textMuted: '#57534e',
  textOnAccent: '#ffffff',
  borderSubtle: '#44403c',
  borderStrong: '#57534e',
  online: '#22c55e',
  teal: '#0d9488',
  unreadBadge: '#ff8c2b',
  away: '#f59e0b',
  dnd: '#f87171',
  dangerText: '#f87171',
  bgTooltip: '#fafaf9',
  textTooltip: '#1c1917',
  gradientStart: '#f97316',
  gradientEnd: '#fb923c',
  googleBlue: '#5b95f5',
} as const;

export type ColorKey = keyof typeof lightColors;
