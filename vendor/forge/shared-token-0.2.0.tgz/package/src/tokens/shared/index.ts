export type { ColorKey } from './colors';
export { darkColors, lightColors } from './colors';
