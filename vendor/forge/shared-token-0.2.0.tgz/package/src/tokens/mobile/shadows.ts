/** React Native shadow definitions — can't be expressed in CSS classes */
export const shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
} as const;

/**
 * Brand-tinted shadows used by Login surfaces (orange glow on light, with the
 * same authoring intent on dark — components can darken or skip on dark mode).
 * `rgb` is the opaque color (RN iOS expects opaque + discrete `shadowOpacity`),
 * `opacity` is the alpha to apply, `offsetY` is the vertical drop, `blur` is the
 * Pencil blur radius (we divide by 2 for `shadowRadius`).
 */
export const brandShadows = {
  logo: { rgb: '#ea580c', opacity: 0.25, offsetY: 8, blur: 32 },
  button: { rgb: '#ea580c', opacity: 0.25, offsetY: 4, blur: 16 },
} as const;
