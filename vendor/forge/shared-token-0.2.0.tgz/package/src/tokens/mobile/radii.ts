/**
 * Corner-radius scale in pixels.
 *
 * Mirrors `--gw-radius-*` CSS variables in variables.css for the values that
 * also exist as classes. `lg: 14` is RN-only — it backs BrandLogo's
 * proportional corner (size * 0.25 at the default 56px).
 *
 * Usage in `*.styles.ts`:
 *
 *   import { radii } from '@gradion/design-system';
 *   export const styles = StyleSheet.create({
 *     card: { borderRadius: radii.md },
 *   });
 */
export const radii = {
  sm: 8, // matches --gw-radius-sm
  md: 12, // matches --gw-radius-md (button corners, gradient surfaces)
  lg: 14, // BrandLogo corner — size * 0.25 at default 56
  xl: 20, // matches --gw-radius-lg (input cards, sheet tops)
  full: 9999, // pill / circle
} as const;
