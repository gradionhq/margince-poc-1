/**
 * Spacing scale in pixels.
 *
 * Mirrors Tailwind's default spacing utilities (1 unit = 4px) so a value
 * referenced as `px-10` in className equals `spacing[10]` in StyleSheet —
 * same layout when authoring with classes vs. inline styles.
 *
 * Half-steps (2.5, 3.5) cover input padding (10, 14) and other component
 * details that don't fit a 4px grid cleanly.
 *
 * Usage in `*.styles.ts`:
 *
 *   import { spacing } from '@gradion/design-system';
 *   import { StyleSheet } from '@gradion/mobile-ui';
 *
 *   export const styles = StyleSheet.create({
 *     body: { paddingHorizontal: spacing[10], paddingVertical: spacing[3] },
 *   });
 *
 * Never hardcode pixel values like `paddingHorizontal: 40` — always reference
 * a token.
 */
export const spacing = {
  0: 0,
  px: 1,
  0.5: 2,
  1: 4,
  1.5: 6,
  2: 8,
  2.5: 10,
  3: 12,
  3.5: 14,
  4: 16,
  5: 20,
  6: 24,
  7: 28,
  8: 32,
  10: 40,
  12: 48,
  16: 64,
  20: 80,
  24: 96,
} as const;
