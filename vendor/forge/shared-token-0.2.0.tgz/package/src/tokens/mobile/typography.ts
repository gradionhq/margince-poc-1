/**
 * Platform-specific font family identifiers.
 *
 * Web consumers reference `"DM Sans"` directly via CSS `--gw-font-body` etc.
 * React Native (gw-mobile) needs the explicit names that `useFonts()` from
 * `@expo-google-fonts/dm-sans` registers — these must match the names used
 * to load the asset modules at app boot. Centralizing them here prevents
 * drift between the loader (App.tsx) and consumer components.
 */
export const fontFamilies = {
  dmSans: {
    regular: 'DMSans_400Regular',
    medium: 'DMSans_500Medium',
    semibold: 'DMSans_600SemiBold',
    bold: 'DMSans_700Bold',
  },
} as const;
