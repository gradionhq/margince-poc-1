/** Avatar dimensions in pixels — for FlashList estimatedItemSize, Reanimated, etc. */
export const avatarSizes = {
  xs: 20,
  sm: 32,
  md: 40,
  lg: 56,
  xl: 80,
} as const;

export const avatarFontSizes = {
  xs: 10,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 24,
} as const;

export const buttonSizes = {
  sm: { height: 32, paddingX: 12, fontSize: 12 },
  md: { height: 40, paddingX: 16, fontSize: 13 },
  lg: { height: 48, paddingX: 24, fontSize: 13 },
} as const;

export const badgeMinWidth = 20;
export const badgeMaxCount = 99;

export const presenceDotSizes = {
  sm: 8,
  md: 10,
  lg: 12,
} as const;

export const iconSizes = {
  sm: 14,
  md: 16,
  // Leading icon size for primary buttons (Pencil U9cEY). Doesn't fit the
  // sm/md/default/lg t-shirt scale cleanly so it's named semantically.
  button: 18,
  default: 20,
  lg: 24,
} as const;
