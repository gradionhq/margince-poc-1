/**
 * Web border-radius scale.
 *
 * Web-only — mobile uses inline numeric values per component. Mirror these
 * in `./variables.css` (`--gf-radius-*`) so Tailwind theme stays in sync.
 */

export const radii = {
  sm: '8px',
  md: '12px',
  lg: '20px',
  full: '9999px',
} as const;

export type RadiusKey = keyof typeof radii;
