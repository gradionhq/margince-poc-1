/**
 * Web typography scale — font families, sizes, weights, line heights.
 *
 * Web-only (no current mobile counterpart). Mirror these in `./variables.css`
 * so Tailwind / CSS consumers stay in sync. The drift-check tool does NOT
 * verify typography — only the shared color subset.
 */

export const fontFamilies = {
  display: '"Outfit", system-ui, sans-serif',
  heading: '"DM Sans", system-ui, sans-serif',
  body: '"DM Sans", system-ui, sans-serif',
  caption: '"DM Sans", system-ui, sans-serif',
  small: '"DM Sans", system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
  label: '"DM Sans", system-ui, sans-serif',
} as const;

export const textVariants = {
  display: { size: '22px', weight: 600, lineHeight: 1.3 },
  heading: { size: '16px', weight: 600, lineHeight: 1.4 },
  body: { size: '14px', weight: 400, lineHeight: 1.5 },
  caption: { size: '13px', weight: 400, lineHeight: 1.4 },
  small: { size: '12px', weight: 400, lineHeight: 1.4 },
  mono: { size: '14px', weight: 400, lineHeight: 1.5 },
  label: { size: '13px', weight: 500, lineHeight: 1.4 },
} as const;

export type TextVariantKey = keyof typeof textVariants;
