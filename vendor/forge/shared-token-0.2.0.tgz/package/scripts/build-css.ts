#!/usr/bin/env tsx
/**
 * Emits a banner-stamped copy of variables.css under dist/. Downstream
 * consumers (gradion-workspace-apps, third-party hosts) read from dist/, not
 * from the source file directly, so the consumer always knows which commit
 * of the design system they shipped against.
 *
 * Usage:
 *   pnpm --filter @gradion/design-system build-css
 *   cat dist/variables.css  # ready to ship
 */

import { execSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const SRC = join(__dirname, '..', 'src', 'tokens', 'web', 'variables.css');
const DIST_DIR = join(__dirname, '..', 'dist');
const DST = join(DIST_DIR, 'variables.css');

function safeGitSha(): string {
  try {
    return execSync('git rev-parse HEAD', { stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .trim();
  } catch {
    return 'unknown';
  }
}

const sha = safeGitSha();
const ts = new Date().toISOString();
const body = readFileSync(SRC, 'utf-8');

const banner = [
  '/*',
  ' * @gradion/design-system — variables.css (generated)',
  ` * Generated: ${ts}`,
  ` * Source SHA: ${sha}`,
  ' * Source:     gw-design-system/src/tokens/web/variables.css',
  ' *',
  ' * Do not hand-edit this file. Regenerate with `pnpm build-css` in',
  ' * gw-design-system. Downstream consumers (plugged-in apps, CDN-hosted',
  ' * surfaces) link to this dist artifact, not the source file directly.',
  ' */',
  '',
  '',
].join('\n');

mkdirSync(DIST_DIR, { recursive: true });
writeFileSync(DST, banner + body);

const bytes = banner.length + body.length;
console.log(`✓ Wrote ${DST} (${bytes} bytes, sha ${sha.slice(0, 7)})`);
