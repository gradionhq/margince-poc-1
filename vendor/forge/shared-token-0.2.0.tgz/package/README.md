# @shared/token

Design tokens for Gradion products. One CSS var prefix: `--gf-`. Light + dark themes, density modes, theme-override hooks (`[data-theme='...']`).

Ported from [forge-design-system](https://git.nfq.asia/josh.ziethen/forge-design-system) `@josh.ziethen/forge-tokens` 0.8.1. The forge repo stays as dev/backup home (tests, stories, full toolchain).

## Surfaces

| Entry | What |
|---|---|
| `@shared/token` | TS index (colors, radii, typography, hooks) |
| `@shared/token/tokens/shared` | Cross-platform color objects |
| `@shared/token/tokens/web` | Web token TS surface |
| `@shared/token/tokens/web/variables.css` | CSS variables (`--gf-*`) |
| `@shared/token/tokens/web/theme.css` | Tailwind v4 `@theme` map |
| `@shared/token/tokens/mobile` | React Native token objects |

## Usage (web)

```css
@import "@shared/token/src/tokens/web/variables.css" layer(base);
@import "@shared/token/src/tokens/web/theme.css";
```

Then use the generated Tailwind utilities (`bg-page`, `text-primary`, `bg-accent`, `p-md`, ...). Never inline hex.

## Notes

- **Source publish**: ships raw TypeScript (`main: ./src/index.ts`). Consumers compile with their own toolchain (Vite, Next, Metro). No `dist/`.
- `pnpm --filter @shared/token check` runs the token drift checker (`gf-ds-check`).
- `pnpm --filter @shared/token build-css` regenerates the CSS files from TS token sources. Commit the result.
